/* Site settings. Edit this file, nothing else needs to change. */
window.STRIVE_CONFIG = {
  /* Leave checkoutUrl empty and EVERYTHING is free (no paywall shown).
     Set it to a real payment link (Stripe Payment Link etc.) to switch the Plus paywall on.
     Note: unlocking Plus after payment must be verified on a server. See README. */
  checkoutUrl: '',
  currency: '$', priceMonth: 12, priceYear: 79, freeBankPerDay: 20
};
