/* Boot: runs after every other script has loaded, so all feature patches are in place.
   The cinematic intro plays the first time only. #skip / reduced-motion / Esc bypass it. */
(function(){
  const e = E(), seen = !!e.introSeen;
  if(matchMedia('(prefers-reduced-motion:reduce)').matches || location.hash==='#skip' || seen){ finish(); }
  else { scrollTo(0,0); e.introSeen = Date.now(); saveState(); }
  document.addEventListener('keydown', ev => {
    if(ev.key==='Escape' && !document.body.classList.contains('done')){
      const i = $('#intro'); if(i && i._skip) i._skip(); else finish();
    }
  });
})();
