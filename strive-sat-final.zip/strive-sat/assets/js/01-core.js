const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const REDUCED = matchMedia('(prefers-reduced-motion:reduce)').matches;
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function shuffle(a){ const b=a.slice(); for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]];} return b; }
const DAY = 86400000;
const ymd = d => { const x = new Date(d); return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0'); };
const todayIdx = () => (new Date().getDay()+6)%7;   // Monday = 0

function toast(msg, icon='ph-info'){
  const t = document.createElement('div'); t.className='toast';
  t.innerHTML = '<i class="ph '+icon+'"></i><span>'+esc(msg)+'</span>';
  $('#toasts').appendChild(t);
  setTimeout(()=>{ t.style.transition='opacity .4s, transform .4s'; t.style.opacity=0; t.style.transform='translateY(10px)'; setTimeout(()=>t.remove(),400); }, 2600);
}
function countTo(el, target, dur=1400, suffix='', dec=0, unitHtml=''){
  if(!el) return;
  if(REDUCED){ el.innerHTML = target.toFixed(dec)+suffix+unitHtml; return; }
  const start = performance.now();
  (function tick(now){
    const p = Math.min((now-start)/dur,1), e = 1-Math.pow(1-p,3);
    el.innerHTML = (e*target).toFixed(dec)+suffix+unitHtml;
    if(p<1) requestAnimationFrame(tick);
  })(start);
}

/* ============================================================
   TOPICS
   ============================================================ */
const TOPICS = {
  math_algebra:{ label:'Math · Algebra', short:'Algebra', sec:'m', icon:'ph-function', desc:'Linear equations, systems, inequalities, word problems.', n:8, min:10 },
  math_adv:{ label:'Math · Advanced', short:'Advanced Math', sec:'m', icon:'ph-sigma', desc:'Quadratics, functions, circles and right triangles.', n:8, min:12 },
  rw_craft:{ label:'R&W · Craft & Structure', short:'Craft & Structure', sec:'rw', icon:'ph-quotes', desc:'Word choice, purpose, main idea and tone.', n:8, min:12 },
  rw_info:{ label:'R&W · Information & Ideas', short:'Information & Ideas', sec:'rw', icon:'ph-lightbulb', desc:'Evidence, inferences and data interpretation.', n:8, min:12 },
  rw_conv:{ label:'R&W · Standard English', short:'Standard English', sec:'rw', icon:'ph-text-aa', desc:'Grammar, punctuation and sentence structure.', n:8, min:10 }
};
const TOPIC_LABEL = Object.assign({}, ...Object.entries(TOPICS).map(([k,v])=>({[k]:v.label})), {mixed:'Mixed · Adaptive'});
const diffRank = d => d==='Easy'?1:d==='Hard'?3:2;

