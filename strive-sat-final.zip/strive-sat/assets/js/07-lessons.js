/* ============================================================
   LESSONS
   ============================================================ */
const LESSONS = [
  { id:'lin', t:'Linear equations in one variable', s:'Math · Algebra · 8 min', ic:'ph-function', topic:'math_algebra',
    lead:'Most algebra questions reduce to one move: do the same thing to both sides until the variable stands alone.',
    pts:['Undo addition and subtraction first, then multiplication and division.','If a question says "no solution" the variable terms cancel but the numbers disagree. "Infinitely many" means both sides become identical.','Check by substituting your answer back in. It takes ten seconds and catches sign errors.'],
    ex:{q:'If 5(x − 2) = 3x + 8, what is x?', steps:['Distribute: 5x − 10 = 3x + 8.','Subtract 3x from both sides: 2x − 10 = 8.','Add 10: 2x = 18.','Divide by 2: x = 9.']} },
  { id:'sys', t:'Systems of linear equations', s:'Math · Algebra · 12 min', ic:'ph-rows', topic:'math_algebra',
    lead:'Two equations, two unknowns. Pick elimination when coefficients line up and substitution when one variable is already isolated.',
    pts:['Elimination: add or subtract the equations so one variable disappears.','Substitution: replace a variable using the other equation.','Same slope with different intercepts means parallel lines, so there is no solution.'],
    ex:{q:'If x + y = 12 and x − y = 4, what is x?', steps:['Add the equations: 2x = 16.','Divide by 2: x = 8.','Then y = 4, and 8 + 4 = 12 checks out.']} },
  { id:'quad', t:'Quadratic functions', s:'Math · Advanced · 15 min', ic:'ph-sigma', topic:'math_adv',
    lead:'A quadratic has three useful faces: standard form, factored form and vertex form. Each one answers a different question fast.',
    pts:['Factored form a(x − r)(x − s) shows the zeros r and s.','Vertex form a(x − h)² + k shows the vertex (h, k).','The vertex x-coordinate in standard form is −b / 2a. The sum of the zeros is −b/a.'],
    ex:{q:'What is the vertex of f(x) = x² − 6x + 5?', steps:['x = −b / 2a = 6 / 2 = 3.','f(3) = 9 − 18 + 5 = −4.','The vertex is (3, −4).']} },
  { id:'exp', t:'Exponential growth and decay', s:'Math · Advanced · 11 min', ic:'ph-trend-up', topic:'math_adv',
    lead:'Anything that multiplies by the same factor over equal time steps is exponential.',
    pts:['Model: y = a · bᵗ. Here a is the starting amount and b is the growth factor per step.','A factor above 1 is growth, between 0 and 1 is decay. 15% growth means b = 1.15.','If the time step is not 1, divide: doubling every 10 years gives a · 2^(t/10).'],
    ex:{q:'A town of 8,000 doubles every 10 years. What is the population after 30 years?', steps:['30 years is 3 doublings.','8,000 · 2³ = 8,000 · 8.','The population is 64,000.']} },
  { id:'word', t:'Word choice and craft', s:'R&W · Craft · 10 min', ic:'ph-quotes', topic:'rw_craft',
    lead:'Fill-in-the-blank questions are clue hunts. The sentence always contains the meaning of the missing word.',
    pts:['Find the clue first, then cover the choices and predict a word yourself.','Contrast signals (although, however, despite) flip the meaning. Continuation signals (and, because) keep it.','Choose the most precise word, not just one that is vaguely right.'],
    ex:{q:'The findings were so ____ that they overturned decades of theory.', steps:['The clue is "overturned decades of theory".','Predict: groundbreaking.','"Revolutionary" matches. "Mundane" and "conventional" contradict the clue.']} },
  { id:'main', t:'Main idea and central claims', s:'R&W · Information · 9 min', ic:'ph-lightbulb', topic:'rw_info',
    lead:'The main idea is what the whole text is doing, not a single detail inside it.',
    pts:['Skim for the sentence that the others support. It is usually the first or last.','Wrong choices are often true details that are too narrow, or claims that go further than the text.','For data questions, read the labels and units before you read the choices.'],
    ex:{q:'A study finds short, frequent sessions beat long, rare ones even when total time is equal. Main idea?', steps:['The comparison is about session frequency.','Total time is held constant, so time is not the cause.','Short, frequent sessions improve results.']} },
  { id:'conv', t:'Standard English conventions', s:'R&W · Conventions · 11 min', ic:'ph-text-aa', topic:'rw_conv',
    lead:'Conventions questions test a small set of rules, over and over. Learn the rules and the questions become mechanical.',
    pts:['The verb agrees with its true subject, not the noun closest to it.','A semicolon joins two complete sentences. A comma alone cannot.','It\'s means "it is". Its shows possession. A singular possessive is \'s, a plural possessive is s\'.'],
    ex:{q:'The team, along with its coach, ____ ready.', steps:['The subject is "team", which is singular.','"Along with its coach" is an interruption and does not change the subject.','The answer is "was".']} },
  { id:'trans', t:'Transitions and logical flow', s:'R&W · Conventions · 8 min', ic:'ph-arrows-clockwise', topic:'rw_conv',
    lead:'A transition names the relationship between two ideas. Decide the relationship first, then pick the word.',
    pts:['Addition: moreover, also. Contrast: however, but. Cause and effect: therefore, so.','Example: for instance. Sequence: then, afterward.','Read the sentence before and after. If the second supports the first, never choose a contrast word.'],
    ex:{q:'The hypothesis was bold. ____, it was supported by three studies.', steps:['The second sentence adds support.','That is addition, not contrast.','"Moreover" fits.']} }
];
function renderLessons(){
  const list=$('#lessonList'); if(!list) return; list.innerHTML='';
  LESSONS.forEach((l,i)=>{
    const p = state.lessonDone[l.id] ? 100 : 0, done = p===100;
    const d=document.createElement('div'); d.className='lesson rv'; d.style.setProperty('--d',i%4);
    d.innerHTML='<div class="ic'+(done?' done':'')+'"><i class="ph '+(done?'ph-check':l.ic)+'"></i></div><div class="tx"><b>'+esc(l.t)+'</b><span>'+esc(l.s)+'</span><div class="bar thin'+(done?' good':'')+'" style="margin-top:12px;max-width:320px"><i data-w="'+p+'"></i></div></div><i class="ph ph-arrow-right arr"></i>';
    d.onclick=()=>openLesson(l.id); list.appendChild(d);
  });
  setTimeout(()=>$$('#lessonList .bar>i').forEach(b=>b.style.width=b.dataset.w+'%'),150);
}
function openLesson(id){
  const l=LESSONS.find(x=>x.id===id), v=$('#lessonView');
  $('#lessonListWrap').classList.add('hidden'); v.classList.remove('hidden');
  v.innerHTML='<div class="lessonbody"><button class="btn ghost sm" id="lsBack"><i class="ph ph-arrow-left"></i>All lessons</button><h2>'+esc(l.t)+'</h2><p class="lead">'+esc(l.lead)+'</p>'+l.pts.map(p=>'<div class="keypoint"><i class="ph ph-check-circle"></i><p>'+esc(p)+'</p></div>').join('')+'<div class="example"><span class="tag acc">Worked example</span><div class="q" style="margin-top:14px">'+esc(l.ex.q)+'</div><ol>'+l.ex.steps.map(s=>'<li>'+esc(s)+'</li>').join('')+'</ol></div><div class="row" style="margin-top:28px"><button class="btn acc lg" id="lsPrac"><i class="ph ph-target"></i>Practice this topic</button><button class="btn lg" id="lsDone"><i class="ph ph-check"></i>Mark complete</button></div></div>';
  scrollTo({top:0,behavior:'instant'});
  $('#lsBack').onclick=()=>closeLesson(false);
  $('#lsPrac').onclick=()=>startPractice(l.topic);
  $('#lsDone').onclick=()=>{ state.lessonDone[l.id]=true; saveState(); toast('Lesson marked complete','ph-check-circle'); closeLesson(false); };
}
function closeLesson(silent){
  const v=$('#lessonView'); if(!v) return; v.classList.add('hidden'); v.innerHTML='';
  $('#lessonListWrap').classList.remove('hidden'); if(!silent) renderLessons();
}

