const IMG={
 "m_wink": "assets/img/m_wink.webp",
 "m_welcome": "assets/img/m_welcome.webp",
 "m_thumbs": "assets/img/m_thumbs.webp",
 "m_cheer": "assets/img/m_cheer.webp",
 "m_trophy": "assets/img/m_trophy.webp",
 "m_think": "assets/img/m_think.webp",
 "m_confused": "assets/img/m_confused.webp",
 "m_headache": "assets/img/m_headache.webp",
 "m_cry": "assets/img/m_cry.webp",
 "m_study": "assets/img/m_study.webp",
 "m_listen": "assets/img/m_listen.webp",
 "avatar": "assets/img/avatar.webp",
 "hero": "assets/img/hero.webp",
 "logo": "assets/img/logo.png",
 "mark": "assets/img/mark.png"
};
