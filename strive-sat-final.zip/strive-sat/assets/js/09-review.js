/* ============================================================
   REVIEW
   ============================================================ */
function renderReview(){
  const list=$('#reviewList'), acts=$('#reviewActs'); list.innerHTML=''; acts.innerHTML='';
  if(!state.missed.length){
    list.innerHTML='<div class="card empty"><img data-mood="trophy" src="'+IMG.m_trophy+'" alt=""><b style="color:var(--tx);font-size:17px">Nothing to review</b><span>When you miss a question it lands here with the full explanation. Answer it correctly later and it leaves the list.</span><button class="btn pri" onclick="go(\'practice\')">Start practice<i class="ph ph-arrow-right"></i></button></div>';
    return;
  }
  acts.innerHTML='<button class="btn acc" onclick="startRetry()"><i class="ph ph-arrows-clockwise"></i>Re-try '+Math.min(10,state.missed.length)+' missed</button>';
  state.missed.slice(0,30).forEach((m,i)=>{
    const q=m.q, d=document.createElement('div'); d.className='reviewitem rv'; d.style.setProperty('--d',i%3);
    const correct = q.spr ? q.ans[0] : q.opts[q.a];
    const chosen = (m.chosen===undefined||m.chosen===-1||m.chosen==='') ? 'Skipped' : (q.spr ? m.chosen : q.opts[m.chosen]);
    d.innerHTML='<div class="rv-icon"><i class="ph ph-x"></i></div><div class="rv-body"><b>'+esc(TOPIC_LABEL[m.topic]||m.topic)+'</b>'+(q.passage?'<div class="muted" style="font-size:13px;line-height:1.6;margin-bottom:10px;font-style:italic">'+esc(q.passage)+'</div>':'')+'<div class="stem">'+(String(m.topic||'').indexOf('math')===0?mxq(q.q):esc(q.q))+'</div><div class="ans" style="color:var(--good)"><i class="ph ph-check-circle"></i><span>Correct: '+(String(m.topic||'').indexOf('math')===0?mx(correct):esc(correct))+'</span></div><div class="ans" style="color:var(--bad)"><i class="ph ph-x-circle"></i><span>You chose: '+(String(m.topic||'').indexOf('math')===0?mx(chosen):esc(chosen))+'</span></div><div class="why">'+(String(m.topic||'').indexOf('math')===0?mx(q.why):esc(q.why))+'</div></div>';
    const rk = m.topic.indexOf('rw')===0 ? 'headache' : 'confused';
    d.insertAdjacentHTML('beforeend', '<img class="rv-mas" data-mood="'+rk+'" src="'+IMG[MOOD[rk]]+'" alt="">');
    list.appendChild(d);
  });
  const rm = $('#reviewMas');
  if(rm){ const k = state.missed.length ? 'think' : 'trophy'; rm.src = IMG[MOOD[k]]; rm.dataset.mood = k; }
}

hydrate(); observeReveals();
