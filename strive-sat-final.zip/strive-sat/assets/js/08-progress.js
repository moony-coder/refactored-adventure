/* ============================================================
   PROGRESS
   ============================================================ */
function renderProgress(){
  countTo($('#pAcc'), accuracy(), 1200, '', 0, '<span class="unit">%</span>');
  countTo($('#pQs'), state.answered, 1200);
  countTo($('#pTime'), state.studyMin.reduce((a,b)=>a+b,0)/60, 1200, '', 1, '<span class="unit">hr</span>');
  const readiness = state.answered ? Math.min(100, Math.round(accuracy()*.9+10)) : 0, r=$('#ring'), rn=$('#ringN'), t0=performance.now();
  (function tick(now){ const p=REDUCED?1:Math.min((now-t0)/1300,1), e=1-Math.pow(1-p,3), v=Math.round(e*readiness); r.style.setProperty('--v',v); rn.innerHTML=v+'<small>%</small>'; if(p<1) requestAnimationFrame(tick); })(t0);
  renderWeekly('#weekly', state.studyMin);
  renderTrend();
  const tw=$('#topicAcc'); tw.innerHTML='';
  Object.keys(TOPICS).forEach(k=>{
    const d=state.byTopic[k]||{attempts:0,correct:0}, acc=d.attempts?Math.round(d.correct/d.attempts*100):0, cls=acc>=80?'good':acc>=60?'':'bad';
    const row=document.createElement('div'); row.className='arow';
    row.innerHTML='<div class="t"><span>'+esc(TOPICS[k].label)+'</span><span class="muted">'+(d.attempts?acc+'%':'No data')+', '+d.attempts+' attempts</span></div><div class="bar thin '+cls+'"><i data-w="'+acc+'"></i></div>';
    tw.appendChild(row);
  });
  setTimeout(()=>$$('#topicAcc .bar>i').forEach(b=>b.style.width=b.dataset.w+'%'),200);
  const act=$('#activity'); act.innerHTML='';
  const recent=state.history.slice(-7).reverse();
  if(!recent.length) act.innerHTML='<div class="empty" style="padding:30px 0"><i class="ph ph-target"></i><span>No activity yet. Start a practice set and it will show up here.</span></div>';
  else recent.forEach(h=>{ const d=document.createElement('div'); d.className='act'; d.innerHTML='<span>'+esc(TOPIC_LABEL[h.topic]||h.topic)+'</span><span class="tag '+(h.correct?'good':'bad')+'"><i class="ph '+(h.correct?'ph-check':'ph-x')+'"></i>'+(h.correct?'Correct':'Missed')+'</span>'; act.appendChild(d); });
}
function renderTrend(){
  const card=$('#trendCard'), pts=state.trend.slice(-10), goal=state.profile.goal||1400;
  if(!pts.length){ $('#trendSvg').innerHTML='<div class="empty" style="padding:36px 0"><i class="ph ph-chart-line-up"></i><span>Your predicted score shows up here after you answer '+MIN_ATTEMPTS+'+ questions in each section.</span></div>'; return; }
  const W=800,H=230,pl=44,pr=16,pt=16,pb=30;
  const vals=pts.map(p=>p.score).concat([goal]); let lo=Math.floor((Math.min(...vals)-40)/50)*50, hi=Math.ceil((Math.max(...vals)+40)/50)*50;
  const X=i=>pl+(pts.length>1?i/(pts.length-1):.5)*(W-pl-pr), Y=v=>pt+(1-(v-lo)/(hi-lo))*(H-pt-pb);
  let d='',a='';
  pts.forEach((p,i)=>{ d+=(i?'L':'M')+X(i).toFixed(1)+' '+Y(p.score).toFixed(1); });
  a=d+' L'+X(pts.length-1).toFixed(1)+' '+(H-pb)+' L'+X(0).toFixed(1)+' '+(H-pb)+' Z';
  let grid='';
  for(let v=lo; v<=hi; v+=Math.max(50,Math.round((hi-lo)/4/50)*50)) grid+='<line class="gl" x1="'+pl+'" x2="'+(W-pr)+'" y1="'+Y(v)+'" y2="'+Y(v)+'"/><text x="'+(pl-8)+'" y="'+(Y(v)+4)+'" text-anchor="end">'+v+'</text>';
  let lastL='';const labels=pts.map((p,i)=>{ const t=new Date(p.ts).toLocaleDateString('en-US',{month:'short',day:'numeric'}); if(t===lastL||!(i%Math.ceil(pts.length/6)===0||i===pts.length-1)) return ''; lastL=t; return '<text x="'+X(i)+'" y="'+(H-8)+'" text-anchor="middle">'+t+'</text>'; }).join('');
  const gy=Y(goal);
  const dots=pts.map((p,i)=>'<circle class="dotc" cx="'+X(i)+'" cy="'+Y(p.score)+'" r="4"><title>'+p.score+'</title></circle>').join('');
  $('#trendSvg').innerHTML='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Predicted score over time"><defs><linearGradient id="tg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4ade80" stop-opacity=".35"/><stop offset="1" stop-color="#4ade80" stop-opacity="0"/></linearGradient></defs>'+grid+'<line x1="'+pl+'" x2="'+(W-pr)+'" y1="'+gy+'" y2="'+gy+'" stroke="#cfe8da" stroke-dasharray="6 6" stroke-opacity=".6"/><text x="'+(W-pr)+'" y="'+(gy-7)+'" text-anchor="end" style="fill:#cfe8da">Goal '+goal+'</text><path class="area" d="'+a+'"/><path class="line" id="trLine" d="'+d+'"/>'+dots+labels+'</svg>';
  const ln=$('#trLine'), len=ln.getTotalLength?Math.ceil(ln.getTotalLength()):2000; ln.style.setProperty('--len',len);
  card.classList.remove('on'); void card.offsetWidth; setTimeout(()=>card.classList.add('on'),120);
}

