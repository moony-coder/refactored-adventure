/* ============================================================
   SETTINGS MODAL
   ============================================================ */
function openModal(html){
  const bg=document.createElement('div'); bg.className='modal-bg'; bg.innerHTML='<div class="modal" role="dialog" aria-modal="true">'+html+'</div>';
  bg.addEventListener('pointerdown', e=>{ if(e.target===bg) bg.remove(); });
  document.body.appendChild(bg); return bg;
}
function openSettings(){
  const p = state.profile;
  const m = openModal('<img src="'+IMG.m_listen+'" data-mood="listen" alt="" style="width:120px;margin:-14px 0 6px"><h2>Your goal</h2><p>Set your name, target score and test date. Everything on the dashboard updates from these.</p>'+
    '<div class="fld"><label for="sName">First name</label><input class="inp" id="sName" value="'+esc(p.name)+'" maxlength="20"></div>'+
    '<div class="fld"><label for="sGoalI">Goal score (400 to 1600)</label><input class="inp" id="sGoalI" type="number" min="400" max="1600" step="10" value="'+p.goal+'"></div>'+
    '<div class="fld"><label for="sDateI">Test date</label><select class="inp" id="sDateI">'+satUpcoming().map(d=>'<option value="'+d.d+'"'+(d.d===p.testDate?' selected':'')+'>'+satLong(d.d)+(d.est?' (anticipated)':'')+'</option>').join('')+'</select></div>'+
    '<div class="acts"><button class="btn danger sm" id="sReset" style="margin-right:auto">Reset progress</button><button class="btn ghost" id="sCancel">Cancel</button><button class="btn pri" id="sSave">Save</button></div>');
  m.querySelector('#sCancel').onclick=()=>m.remove();
  m.querySelector('#sSave').onclick=()=>{
    p.name = m.querySelector('#sName').value.trim() || p.name || 'Student';
    p.goal = Math.min(1600, Math.max(400, parseInt(m.querySelector('#sGoalI').value)||p.goal||1400));
    p.testDate = m.querySelector('#sDateI').value || p.testDate;
    saveState(); m.remove(); animateDash(); toast('Saved','ph-check-circle');
  };
  m.querySelector('#sReset').onclick=()=>{ const go=()=>{ localStorage.removeItem(STORE_KEY); location.href='onboarding.html'; };
    if(window.UI) UI.confirm({title:'Reset all progress?',text:'This deletes ALL your progress and settings on this device. It cannot be undone.',ok:'Yes, reset',cancel:'Keep my progress',danger:true}).then(y=>{ if(y) go(); });
    else if(confirm('Delete ALL your progress and settings on this device? This cannot be undone.')) go(); };
}

loadState();
