/* /onboarding: asks the new student a few real questions and saves them as their profile.
   Everything lives in this browser (localStorage key 'strive_sat_v3'); nothing is sent anywhere. */
const STORE_KEY = 'strive_sat_v3';
const DAY = 86400000;
const ymd = d => { const x = new Date(d); return x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0'); };
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

(function(){
  const params = new URLSearchParams(location.search);
  const EDIT = params.has('edit');
  let saved = null;
  try{ saved = JSON.parse(localStorage.getItem(STORE_KEY) || 'null'); }catch(e){}
  if(saved && saved.profile && saved.profile.onboarded && !EDIT){ location.replace('app.html'); return; }
  if(EDIT) $('#editBack').hidden = false;

  const P = (saved && saved.profile) || {};
  const d = {
    name: P.name || '', grade: P.grade || '', testDate: P.testDate || '',
    goal: P.goal || 1400, haveScore: P.startScore ? true : (P.startScore === 0 ? false : null),
    startScore: P.startScore || '', daily: (saved && saved.ext && saved.ext.goal) || 10
  };

  const GRADES = [['9','9th grade'],['10','10th grade'],['11','11th grade'],['12','12th grade'],['other','Gap year or other']];
  const DAILY = [[5,'Light'],[10,'Steady'],[20,'Serious'],[30,'All in']];
  const upcoming = () => SAT_DATES.filter(x => x.d >= ymd(Date.now()));
  const regNote = x => {
    if(x.est) return 'Dates anticipated';
    const t = ymd(Date.now());
    if(t <= x.r) return 'Register by ' + satShort(x.r);
    if(t <= x.l) return 'Late registration only';
    return 'Registration closed';
  };
  const mins = n => Math.round(n * 1.5);
  const fmtDays = s => Math.max(0, Math.ceil((new Date(s+'T00:00:00') - new Date()) / DAY));

  let showAllDates = false;

  const STEPS = [
    { mood:'m_welcome', bubble:'Hey there!', count:'Welcome',
      title:()=>'Welcome to <em>Strive</em>. What should I call you?',
      sub:()=>'I am your SAT coach from Jamal\'s International Academy. A few quick questions and I will build your climb.',
      render(b){ b.innerHTML='<label class="sr" for="fName" style="position:absolute;left:-9999px">First name</label><input class="inp" id="fName" maxlength="20" placeholder="Your first name" autocomplete="given-name" autocapitalize="words" value="'+esc(d.name)+'">'; },
      focus:'#fName',
      read(){ d.name = $('#fName').value.trim().replace(/\s+/g,' '); },
      check(){ return d.name.length < 1 ? 'Please type your first name.' : (d.name.length > 20 ? 'Keep it to 20 characters.' : ''); } },

    { mood:'m_study', bubble:'Nice to meet you!', count:'About you',
      title:()=>'Nice to meet you, <em>'+esc(d.name)+'</em>. Which grade are you in?',
      sub:()=>'This helps me pace your plan. You can change it later.',
      render(b){ b.innerHTML='<div class="chips" role="radiogroup" aria-label="Grade">'+GRADES.map(g=>'<button type="button" class="opt" role="radio" data-v="'+g[0]+'" aria-checked="'+(d.grade===g[0])+'">'+g[1]+'</button>').join('')+'</div>'; },
      bind(b){ b.querySelectorAll('.opt').forEach(o=>o.onclick=()=>{ d.grade=o.dataset.v; b.querySelectorAll('.opt').forEach(x=>x.setAttribute('aria-checked',x===o)); setErr(''); }); },
      read(){}, check(){ return d.grade ? '' : 'Pick the option that fits you best.'; } },

    { mood:'m_think', bubble:'Pick your day', count:'Test date',
      title:()=>'When is your <em>test day</em>?',
      sub:()=>'These are the College Board SAT dates. Pick the one you are aiming for. Your countdown starts right away.',
      render(b){
        const all = upcoming(), list = showAllDates ? all : all.slice(0,6);
        if(!all.length){ b.innerHTML='<input class="inp sm" id="fDate" type="date" min="'+ymd(Date.now())+'" value="'+esc(d.testDate)+'" aria-label="Test date">'; return; }
        b.innerHTML='<div class="list '+(showAllDates?'scroll':'')+'" role="radiogroup" aria-label="Test date">'+list.map(x=>'<button type="button" class="opt" role="radio" data-v="'+x.d+'" aria-checked="'+(d.testDate===x.d)+'"><span>'+satLong(x.d)+'<small>'+fmtDays(x.d)+' days from today</small></span><span class="r">'+regNote(x)+'</span></button>').join('')+'</div>'
          + (!showAllDates && all.length>6 ? '<button type="button" class="more" id="moreD">Show later dates</button>' : '');
      },
      bind(b){
        b.querySelectorAll('.opt').forEach(o=>o.onclick=()=>{ d.testDate=o.dataset.v; b.querySelectorAll('.opt').forEach(x=>x.setAttribute('aria-checked',x===o)); setErr(''); });
        const m=$('#moreD'); if(m) m.onclick=()=>{ showAllDates=true; paint(false); };
      },
      read(){ const f=$('#fDate'); if(f) d.testDate=f.value; },
      check(){ return !d.testDate ? 'Choose your test date.' : (d.testDate < ymd(Date.now()) ? 'That date has already passed.' : ''); } },

    { mood:'m_cheer', bubble:'Aim high!', count:'Your goal',
      title:()=>'What score are you <em>climbing</em> to?',
      sub:()=>'Total score out of 1600. Pick something ambitious but real. You can raise it later.',
      render(b){
        b.innerHTML='<div class="big"><b id="gv">'+d.goal+'</b><span>/ 1600</span></div>'
         +'<input type="range" id="gr" min="800" max="1600" step="10" value="'+d.goal+'" aria-label="Goal score">'
         +'<div class="chips" aria-label="Quick picks">'+[1200,1300,1400,1500,1600].map(v=>'<button type="button" class="opt" data-q="'+v+'">'+v+'</button>').join('')+'</div>';
        setRange();
      },
      bind(b){
        const r=$('#gr'); r.oninput=()=>{ d.goal=+r.value; setRange(); };
        b.querySelectorAll('[data-q]').forEach(o=>o.onclick=()=>{ d.goal=+o.dataset.q; r.value=d.goal; setRange(); });
      },
      read(){}, check(){ return (d.goal>=400 && d.goal<=1600) ? '' : 'Goal must be between 400 and 1600.'; } },

    { mood:'m_listen', bubble:'Be honest!', count:'Starting point',
      title:()=>'Have you taken the SAT or a <em>full practice test</em>?',
      sub:()=>'No pressure either way. If you have a score, I will use it as your starting point. I will not invent one for you.',
      render(b){
        b.innerHTML='<div class="chips" role="radiogroup" aria-label="Previous score">'
         +'<button type="button" class="opt" role="radio" data-v="yes" aria-checked="'+(d.haveScore===true)+'">Yes, I have a score</button>'
         +'<button type="button" class="opt" role="radio" data-v="no" aria-checked="'+(d.haveScore===false)+'">Not yet<small>I will find out here</small></button></div>'
         +'<div id="scoreWrap" style="margin-top:18px" '+(d.haveScore===true?'':'hidden')+'><input class="inp sm" id="fScore" type="number" inputmode="numeric" min="400" max="1600" step="10" placeholder="Your latest total (400 to 1600)" aria-label="Latest total score" value="'+esc(d.startScore)+'"></div>';
      },
      bind(b){ b.querySelectorAll('.opt').forEach(o=>o.onclick=()=>{ d.haveScore = o.dataset.v==='yes'; b.querySelectorAll('.opt').forEach(x=>x.setAttribute('aria-checked',x===o)); $('#scoreWrap').hidden=!d.haveScore; if(d.haveScore) $('#fScore').focus(); setErr(''); }); },
      read(){ const f=$('#fScore'); if(f && d.haveScore) d.startScore = f.value.trim(); },
      check(){
        if(d.haveScore===null) return 'Choose one so I know where to start.';
        if(d.haveScore){ const n=+d.startScore; if(!d.startScore || !Number.isFinite(n) || n<400 || n>1600) return 'Enter a score between 400 and 1600.'; }
        return '';
      } },

    { mood:'m_wink', bubble:'Little by little', count:'Your routine',
      title:()=>'How many questions a day feels <em>doable</em>?',
      sub:()=>'Consistency beats cramming. Your daily goal drives your streak and rewards.',
      render(b){ b.innerHTML='<div class="list" role="radiogroup" aria-label="Daily goal">'+DAILY.map(x=>'<button type="button" class="opt" role="radio" data-v="'+x[0]+'" aria-checked="'+(d.daily===x[0])+'"><span>'+x[0]+' questions<small>'+x[1]+', about '+mins(x[0])+' minutes a day</small></span></button>').join('')+'</div>'; },
      bind(b){ b.querySelectorAll('.opt').forEach(o=>o.onclick=()=>{ d.daily=+o.dataset.v; b.querySelectorAll('.opt').forEach(x=>x.setAttribute('aria-checked',x===o)); setErr(''); }); },
      read(){}, check(){ return DAILY.some(x=>x[0]===d.daily) ? '' : 'Pick a daily goal.'; } },

    { mood:'m_trophy', bubble:'Let\'s climb!', count:'All set', last:true,
      title:()=>'You are ready, <em>'+esc(d.name)+'</em>.',
      sub:()=>'Here is your starting plan. Everything on your dashboard begins empty and fills with what you actually do.',
      render(b){
        const days=fmtDays(d.testDate), weeks=Math.max(1,Math.ceil(days/7)), total=days*d.daily;
        const gain = d.haveScore ? (d.goal - (+d.startScore)) : null;
        b.innerHTML='<div class="sum">'
         +'<div><span>Test day</span><b>'+esc(satShort(d.testDate))+'</b></div>'
         +'<div><span>Days to climb</span><b>'+days+'</b></div>'
         +'<div><span>Goal score</span><b>'+d.goal+'</b></div>'
         +'<div><span>'+(gain!=null?'From your '+(+d.startScore):'Starting point')+'</span><b>'+(gain!=null?(gain>0?'+'+gain+' pts':'Already there'):'Found in your first session')+'</b></div>'
         +'<div class="w"><span>Your routine</span><b>'+d.daily+' questions a day, about '+mins(d.daily)+' min. Over '+weeks+' week'+(weeks===1?'':'s')+' that is up to '+total.toLocaleString('en-US')+' questions.</b></div></div>'
         +'<p class="hint">Next, a short diagnostic across every topic finds your weak spots, then your plan builds itself.</p>';
      },
      read(){}, check(){ return ''; } }
  ];

  const stepsEl = $('#steps');
  STEPS.forEach(()=>stepsEl.appendChild(document.createElement('i')));
  let i = 0;
  const body = $('#body'), form = $('#form');

  function setErr(t){ $('#err').textContent = t || ''; }
  function setRange(){
    const r=$('#gr'), v=$('#gv'); if(!r) return;
    v.textContent = d.goal; r.style.setProperty('--p', ((d.goal-800)/800*100)+'%');
  }
  function paint(animate=true){
    const s = STEPS[i];
    $('#count').textContent = (i+1)+' of '+STEPS.length+' · '+s.count;
    $('#title').innerHTML = s.title(); $('#sub').textContent = s.sub();
    $('#bubble').textContent = s.bubble;
    const img = $('#mas'); const src='assets/img/'+s.mood+'.webp';
    if(!img.src.endsWith(src)){ img.classList.add('sw'); setTimeout(()=>{ img.src=src; img.classList.remove('sw'); },180); }
    s.render(body); if(s.bind) s.bind(body);
    [...stepsEl.children].forEach((el,k)=>el.classList.toggle('on',k<=i));
    stepsEl.setAttribute('aria-valuenow', i+1);
    $('#back').disabled = i===0;
    $('#nextL').textContent = s.last ? (EDIT?'Save changes':'Start climbing') : 'Continue';
    $('#fine').hidden = i!==0;
    setErr('');
    if(animate){ form.classList.remove('in'); void form.offsetWidth; form.classList.add('in'); }
    const f = s.focus && $(s.focus);
    if(f && animate) setTimeout(()=>f.focus({preventScroll:true}), 60); else if(animate) $('#title').focus({preventScroll:true});
  }

  function save(){
    let cur = {};
    try{ cur = JSON.parse(localStorage.getItem(STORE_KEY) || '{}') || {}; }catch(e){ cur = {}; }
    cur.v = 3; cur.createdAt = cur.createdAt || Date.now();
    cur.profile = Object.assign({}, cur.profile, {
      name: d.name, grade: d.grade, goal: d.goal, testDate: d.testDate,
      startScore: d.haveScore ? +d.startScore : 0, onboarded: true, onboardedAt: (cur.profile && cur.profile.onboardedAt) || Date.now()
    });
    cur.ext = Object.assign({}, cur.ext, { goal: d.daily });
    localStorage.setItem(STORE_KEY, JSON.stringify(cur));
  }

  form.addEventListener('submit', e=>{
    e.preventDefault();
    const s = STEPS[i]; s.read(); const msg = s.check();
    if(msg){ setErr(msg); const f=body.querySelector('input,.opt'); if(f) f.focus({preventScroll:true}); return; }
    if(s.last){
      try{ save(); }catch(err){ setErr('Your browser blocked saving. Turn off private mode or allow site storage, then try again.'); return; }
      $('#next').disabled = true; location.href = 'app.html';
      return;
    }
    i++; paint();
  });
  $('#back').onclick = ()=>{ if(i>0){ STEPS[i].read(); i--; paint(); } };

  paint();
})();
