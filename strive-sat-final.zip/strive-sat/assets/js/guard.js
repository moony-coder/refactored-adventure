/* Runs before the app paints: students who have not finished /onboarding are sent there. */
(function(){
  try{
    var s = JSON.parse(localStorage.getItem('strive_sat_v3') || 'null');
    if(!s || !s.profile || !s.profile.onboarded) location.replace('onboarding.html');
  }catch(e){ location.replace('onboarding.html'); }
})();
