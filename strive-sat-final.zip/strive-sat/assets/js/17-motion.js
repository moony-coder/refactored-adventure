/* ============================================================
   MOTION: view transitions, staggered entrances, sliding nav pill,
   card tilt, button ripples. Loaded last (before 99-boot).
   Everything degrades to the old behaviour if unsupported.
   ============================================================ */
(function(){
  'use strict';
  if(typeof go !== 'function') return;
  const $ = (s, r) => (r||document).querySelector(s);
  const $$ = (s, r) => Array.from((r||document).querySelectorAll(s));
  const REDUCED = matchMedia('(prefers-reduced-motion:reduce)').matches;
  const canVT = !REDUCED && typeof document.startViewTransition === 'function';
  if(canVT) document.documentElement.classList.add('vt');

  /* ---------- sliding pill ---------- */
  const nav = $('#nav');
  let pill = null;
  function placePill(){
    if(!nav) return;
    const a = $('button.active', nav); if(!a) return;
    if(!pill){ pill = document.createElement('i'); pill.className = 'nx-pill'; nav.prepend(pill); }
    pill.style.height = a.offsetHeight+'px';
    pill.style.setProperty('--y', a.offsetTop+'px');
    nav.classList.add('has-pill');
  }
  addEventListener('resize', placePill);
  document.fonts && document.fonts.ready.then(placePill);

  /* ---------- stagger ---------- */
  function stagger(view){
    if(REDUCED || !view) return;
    let i = 0;
    const kids = [];
    Array.from(view.children).forEach(c => {
      if(c.classList.contains('hidden') || c.id === 'onb' && !c.children.length) return;
      const cs = getComputedStyle(c);
      if(cs.display === 'grid' && c.children.length > 1 && !c.classList.contains('card')) Array.from(c.children).forEach(g => kids.push(g)); else kids.push(c);
    });
    const vh = innerHeight;
    kids.forEach(k => {
      const r = k.getBoundingClientRect();
      if(r.top > vh * 1.1 || k.classList.contains('rv')) return;   // below the fold: the existing reveal handles it
      k.classList.remove('nx-in'); void k.offsetWidth;
      k.style.setProperty('--i', Math.min(i++, 12)); k.classList.add('nx-in');
      k.addEventListener('animationend', () => { k.classList.remove('nx-in'); k.style.removeProperty('--i'); }, { once:true });
    });
  }

  /* ---------- wrap go() ---------- */
  const _go = go;
  let busy = false;
  go = function(name){
    const same = name === (typeof currentView !== 'undefined' ? currentView : null);
    const run = () => { _go(name); placePill(); const v = $('#v-'+name); if(v) { v.style.animation = canVT ? 'none' : ''; stagger(v); } };
    if(canVT && !same && !busy && document.body.classList.contains('done') !== false){
      busy = true;
      try{
        const t = document.startViewTransition(run);
        t.finished.finally(() => { busy = false; });
        t.ready.then(() => { if(innerWidth > 0) scrollTo({ top:0, behavior:'instant' }); }).catch(() => {});
      }catch(e){ busy = false; run(); }
    } else run();
  };
  // anything that calls the old go by closure keeps working; nav buttons use the global
  addEventListener('load', () => { placePill(); const v = $('.view:not(.hidden)'); stagger(v); });
  setTimeout(placePill, 400); setTimeout(placePill, 1500);

  /* ---------- card tilt (mouse only) ---------- */
  if(!REDUCED && matchMedia('(hover:hover) and (pointer:fine)').matches){
    document.addEventListener('pointermove', e => {
      const c = e.target.closest && e.target.closest('.card');
      const act = document._tilt;
      if(act && act !== c){ act.classList.remove('live'); act.style.transform = ''; document._tilt = null; }
      if(!c) return;
      const clickable = c.matches('button,a,[onclick],[data-t],[data-k],[data-topic],[data-id],[data-l]') || c.querySelector(':scope > [onclick]');
      if(!clickable || c.offsetWidth > 520) return;
      const r = c.getBoundingClientRect(), x = (e.clientX - r.left)/r.width - .5, y = (e.clientY - r.top)/r.height - .5;
      c.classList.add('tilt', 'live'); document._tilt = c;
      c.style.transform = 'perspective(900px) rotateX('+(-y*5).toFixed(2)+'deg) rotateY('+(x*6).toFixed(2)+'deg) translateY(-3px)';
    }, { passive:true });
    document.addEventListener('pointerleave', () => { const a = document._tilt; if(a){ a.classList.remove('live'); a.style.transform = ''; document._tilt = null; } }, true);
  }

  /* ---------- ripple on primary buttons ---------- */
  document.addEventListener('pointerdown', e => {
    const b = e.target.closest && e.target.closest('.btn.acc,.btn.pri,.btn.line');
    if(!b || REDUCED) return;
    const r = b.getBoundingClientRect(), s = Math.max(r.width, r.height) * 2.2;
    const d = document.createElement('span'); d.className = 'nx-rip';
    d.style.cssText = 'width:'+s+'px;height:'+s+'px;left:'+(e.clientX - r.left - s/2)+'px;top:'+(e.clientY - r.top - s/2)+'px';
    b.appendChild(d); setTimeout(() => d.remove(), 700);
  });
})();
