/* ============================================================
   WATCH: video lessons that feel native to the app.

   - Videos are only LINKS (assets/data/videos.js). Nothing is stored or uploaded.
   - The source's own player chrome is hidden. The student sees our poster, our controls,
     our colours. Playback is the official embedded player running underneath.
   - Nothing from the video host loads until the student presses play.
   - Progress and resume position are saved in the student's own browser.
   ============================================================ */
(function(){
  'use strict';

  /* ---------- link parsing ---------- */
  const ID_RE = /^[\w-]{11}$/;
  function parseTime(s){
    if(!s) return 0;
    if(/^\d+$/.test(s)) return +s;
    const m = String(s).match(/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s?)?$/);
    return m ? (+m[1]||0)*3600 + (+m[2]||0)*60 + (+m[3]||0) : 0;
  }
  function parseLink(raw){
    const s = String(raw||'').trim(); let id = null, t = 0;
    if(ID_RE.test(s)) id = s;
    else {
      try{
        const u = new URL(/^https?:\/\//i.test(s) ? s : 'https://'+s);
        const h = u.hostname.replace(/^(www|m|music)\./,'');
        if(h==='youtu.be') id = u.pathname.slice(1).split('/')[0];
        else if(/(^|\.)youtube(-nocookie)?\.com$/.test(h)){
          if(u.pathname==='/watch') id = u.searchParams.get('v');
          else { const m = u.pathname.match(/^\/(embed|shorts|live|v)\/([\w-]{11})/); if(m) id = m[2]; }
        }
        t = parseTime(u.searchParams.get('t') || u.searchParams.get('start') || (u.hash.match(/t=([\w]+)/)||[])[1]);
      }catch(e){}
    }
    return id && ID_RE.test(id) ? { id, t } : null;
  }

  /* ---------- library ---------- */
  const SEC = { m:'Math', rw:'Reading & Writing', tips:'Strategy' };
  const LIB = (window.VIDEOS||[]).map(x => {
    const p = parseLink(x.link); if(!p) return null;
    return { id:p.id, start:p.t, sec:x.sec||'tips', topic:x.topic||'', t:x.t, by:x.by, why:x.why };
  }).filter(Boolean).filter((v,i,a) => a.findIndex(o => o.id===v.id) === i);
  const byId = id => LIB.find(v => v.id===id);

  /* ---- auto-classify (only for entries left on 'auto') and auto-hide unembeddable videos ---- */
  const MATH_RE = /math|algebra|geometr|equation|function|quadratic|linear|trig|desmos|calculator|graph|percent|ratio|probab|statist|exponent|polynomial|inequalit|circle|triangle|ریاضی|رياضيات|حساب/i;
  const RW_RE = /reading|writing|grammar|vocab|comma|passage|evidence|inference|transition|punctuation|sentence|essay|rhetor|words in context|conventions|english|قراءة|اردو/i;
  function classify(v){
    if(v.pinned) return;
    const t = v.t || '';
    if(MATH_RE.test(t)){ v.sec = 'm'; v.topic = v.topic || (/algebra|linear|equation|inequalit/i.test(t) ? 'math_algebra' : 'math_adv'); }
    else if(RW_RE.test(t)){ v.sec = 'rw'; v.topic = v.topic || (/grammar|comma|punctuation|sentence|conventions/i.test(t) ? 'rw_conv' : /main idea|inference|evidence|passage|reading/i.test(t) ? 'rw_info' : 'rw_craft'); }
    else v.sec = 'tips';
  }
  LIB.forEach(v => { v.pinned = !!(window.VIDEOS.find(x => (parseLink(x.link)||{}).id === v.id) || {}).sec && window.VIDEOS.find(x => (parseLink(x.link)||{}).id === v.id).sec !== 'auto'; });
  function hydrate(){
    let left = LIB.length;
    const done = () => { if(--left > 0) return; try{ if(typeof currentView !== 'undefined'){ if(currentView === 'watch') renderWatch(); if(currentView === 'dash') animateDash(); } }catch(e){} };
    LIB.slice().forEach(v => {
      fetch('https://www.youtube.com/oembed?format=json&url='+encodeURIComponent('https://www.youtube.com/watch?v='+v.id))
        .then(r => {
          if([401,403,404].includes(r.status)){ const i = LIB.indexOf(v); if(i > -1) LIB.splice(i,1); return null; }  /* embedding off / private / removed */
          return r.ok ? r.json() : null;
        })
        .then(d => { if(d){ v.t = v.t || d.title; v.by = v.by || d.author_name; classify(v); } })
        .catch(() => { classify(v); })
        .finally(done);
    });
  }
  setTimeout(hydrate, 0);

  /* fill in missing titles from the public oEmbed endpoint (no key, no storage) */
  const metaTried = {};
  function ensureMeta(v){
    if(v.t && v.by) return Promise.resolve(v);
    if(metaTried[v.id]) return metaTried[v.id];
    return metaTried[v.id] = fetch('https://www.youtube.com/oembed?format=json&url='+encodeURIComponent('https://www.youtube.com/watch?v='+v.id))
      .then(r => r.ok ? r.json() : Promise.reject()).then(d => { v.t = v.t || d.title; v.by = v.by || d.author_name; return v; })
      .catch(() => { v.t = v.t || 'Video lesson'; return v; });
  }

  /* ---------- saved progress ---------- */
  const vstore = () => { const e = E(); return e.vid = e.vid || {}; };
  const vget = id => vstore()[id] || {};
  function vset(id, patch){ const s = vstore(); s[id] = Object.assign(s[id]||{}, patch, { ts:Date.now() }); saveState(); }
  const watchedN = () => LIB.filter(v => vget(v.id).done).length;
  function lastUnfinished(){
    let best = null;
    LIB.forEach(v => { const p = vget(v.id); if(p.t > 5 && !p.done && (!best || p.ts > best.p.ts)) best = { v, p }; });
    return best && best.v;
  }

  /* ---------- helpers ---------- */
  const fmt = s => { s = Math.max(0, Math.floor(s||0)); const h = Math.floor(s/3600), m = Math.floor(s%3600/60), x = s%60;
    return (h ? h+':'+String(m).padStart(2,'0') : m)+':'+String(x).padStart(2,'0'); };
  const I = (n, fill) => '<i class="ph'+(fill?'-fill':'')+' ph-'+n+'"></i>';
  const SK = (n, fwd) => '<svg viewBox="0 0 24 24" aria-hidden="true"><g class="g" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4.6a8.4 8.4 0 1 1-8.1 6.2"/><path d="M13.7 1.9 10.6 4.6l3.1 2.7"/></g><text x="12" y="15.4" text-anchor="middle" font-size="7.4" fill="currentColor">'+n+'</text></svg>';
  const CH = '<svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="m7 4 6 6-6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const KEYS = [['Play / pause','Space','K'],['Back 10 s','J'],['Forward 10 s','L'],['Back 5 s','←'],['Forward 5 s','→'],['Volume','↑','↓'],['Mute','M'],['Full screen','F'],['Slower / faster','<','>'],['Jump to %','0–9'],['Start / end','Home','End'],['This sheet','?']];
  const clamp = (x,a,b) => Math.min(b, Math.max(a, x));
  const RATES = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

  function poster(id, cb){
    const tries = ['maxresdefault','sddefault','hqdefault']; let i = 0;
    (function next(){
      const img = new Image(), u = 'https://i.ytimg.com/vi/'+id+'/'+tries[i]+'.jpg';
      img.onload = () => (img.naturalWidth > 200 || i === tries.length-1) ? cb(u) : (i++, next());
      img.onerror = () => i < tries.length-1 ? (i++, next()) : cb('');
      img.src = u;
    })();
  }

  let apiP = null;
  function loadAPI(){
    if(window.YT && YT.Player) return Promise.resolve();
    if(apiP) return apiP;
    return apiP = new Promise((res, rej) => {
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => { try{ prev && prev(); }catch(e){} res(); };
      const s = document.createElement('script'); s.src = 'https://www.youtube.com/iframe_api';
      s.onerror = () => { apiP = null; rej(new Error('blocked')); };
      document.head.appendChild(s);
      setTimeout(() => { if(!(window.YT && YT.Player)){ apiP = null; rej(new Error('timeout')); } }, 15000);
    });
  }

  /* ============================================================
     PLAYER
     ============================================================ */
  const live = new Set();
  let uid = 0;

  function makePlayer(host, v, o){
    o = o || {};
    const pid = 'vpm'+(++uid);
    const saved = vget(v.id);
    const startAt = (saved.t > 5 && !saved.done && (!saved.d || saved.t < saved.d-8)) ? saved.t : (v.start || 0);
    const root = document.createElement('div');
    root.className = 'vp'+(o.compact?' compact':'');
    root.tabIndex = 0;
    root.setAttribute('role','group'); root.setAttribute('aria-label','Video: '+(v.t||'lesson'));
    root.innerHTML =
      '<div class="vp-stage">'+
        '<div class="vp-yt"><div id="'+pid+'"></div></div>'+
        '<div class="vp-poster"><div class="vp-pcopy"><span class="tag">'+I('film-strip',1)+esc(SEC[v.sec]||'Video')+(startAt>5?' · resume '+fmt(startAt):'')+'</span><b>'+esc(v.t||'')+'</b><span class="by">'+esc(v.by||'')+'</span></div></div>'+
        '<div class="vp-big">'+I('play',1)+'</div>'+
        '<div class="vp-pausebtn">'+I('play',1)+'</div>'+
        '<div class="vp-sk l"><div class="ch">'+CH+CH+CH+'</div><span></span></div><div class="vp-sk r"><div class="ch">'+CH+CH+CH+'</div><span></span></div><div class="vp-bz" aria-hidden="true"></div>'+
        '<div class="vp-hit"></div>'+
        '<div class="vp-load"></div>'+
        '<div class="vp-ctrl">'+
          '<div class="vp-seek" role="slider" aria-label="Seek" aria-valuemin="0" tabindex="0"><div class="vp-rail"><div class="vp-buf"></div><div class="vp-fill"></div><div class="vp-knob"></div></div><div class="vp-tip">0:00</div></div>'+
          '<div class="vp-row">'+
            '<button class="vp-b" data-a="play" aria-label="Play or pause" title="Play / pause (K)">'+I('play',1)+'</button>'+
            '<button class="vp-b sk" data-a="back" aria-label="Back 10 seconds" title="Back 10 seconds (J)">'+SK(10)+'</button>'+
            '<button class="vp-b sk f" data-a="fwd" aria-label="Forward 10 seconds" title="Forward 10 seconds (L)">'+SK(10)+'</button>'+
            '<div class="vp-vol"><button class="vp-b" data-a="mute" aria-label="Mute" title="Mute (M)">'+I('speaker-high')+'</button><input type="range" min="0" max="100" value="100" aria-label="Volume"></div>'+
            '<span class="vp-time"><b class="c">0:00</b> / <span class="d">0:00</span></span>'+
            '<span class="sp"></span>'+
            '<button class="vp-b kb" data-a="keys" aria-label="Keyboard shortcuts" title="Shortcuts (?)">'+I('keyboard')+'</button>'+
            '<button class="vp-b txt rate" data-a="rate" aria-label="Playback speed" title="Speed"><b>1×</b></button>'+
            '<button class="vp-b" data-a="fs" aria-label="Full screen" title="Full screen (F)">'+I('corners-out')+'</button>'+
          '</div>'+
        '</div>'+
        '<div class="vp-keys" role="dialog" aria-label="Keyboard shortcuts"><div class="in"><h5>Keyboard shortcuts<button type="button" data-a="keys" aria-label="Close">'+I('x')+'</button></h5><dl>'+KEYS.map(k => '<div><dd>'+k[0]+'</dd><dt>'+k.slice(1).map(x => '<kbd>'+x+'</kbd>').join('')+'</dt></div>').join('')+'</dl></div></div>'+
        '<div class="vp-menu" role="menu">'+RATES.map(r => '<button data-r="'+r+'" role="menuitem">'+(r===1?'Normal':r+'×')+'</button>').join('')+'</div>'+
        '<div class="vp-end"><div class="in"><div class="ok">'+I('check',1)+'</div><h4>Nice, you finished it</h4><p>'+esc(v.t||'')+'</p><div class="row"></div></div></div>'+
        '<div class="vp-err"><div class="in"><div class="ic">'+I('warning-circle',1)+'</div><b>This video will not play here</b><p>It may be private, removed, or blocked on this network. Check your connection, or try another video.</p><div class="row" style="margin-top:6px"><button class="btn line sm" data-a="retry">'+I('arrow-clockwise')+'Try again</button><a class="btn ghost sm" target="_blank" rel="noopener" href="https://www.youtube.com/watch?v='+v.id+(startAt>5?'&t='+Math.floor(startAt)+'s':'')+'">'+I('arrow-square-out')+'Open original</a></div></div></div>'+
      '</div>';
    host.innerHTML = ''; host.appendChild(root);

    const q = s => root.querySelector(s), qa = s => root.querySelectorAll(s);
    const seek = q('.vp-seek'), fill = q('.vp-fill'), buf = q('.vp-buf'), knob = q('.vp-knob'), tip = q('.vp-tip');
    const cEl = q('.c'), dEl = q('.d'), vol = q('.vp-vol input'), menu = q('.vp-menu');
    const playIco = q('[data-a=play] i'), pauseBtnIco = q('.vp-pausebtn i'), muteIco = q('[data-a=mute] i'), fsIco = q('[data-a=fs] i');

    let yt = null, ready = false, state = -2, dur = 0, tmr = 0, saveTmr = 0, idleTmr = 0, dead = false;
    let acc = 0, lastTick = 0, drag = false, fake = false, vlevel = (E().vol == null ? 100 : E().vol), want = false;

    poster(v.id, u => { if(dead) return; const p = q('.vp-poster'); if(u){ p.style.backgroundImage = 'url("'+u+'")'; if(o.glow) o.glow(u); } });
    ensureMeta(v).then(() => { if(dead) return; q('.vp-pcopy b').textContent = v.t; q('.vp-pcopy .by').textContent = v.by||''; q('.vp-end p').textContent = v.t; if(o.onMeta) o.onMeta(v); });

    /* ----- ui state ----- */
    const cls = (c, on) => root.classList.toggle(c, !!on);
    const isPlaying = () => state === 1 || state === 3 && !root.classList.contains('is-paused');
    function paint(){
      const cur = ready ? (yt.getCurrentTime()||0) : 0;
      if(ready){ const d = yt.getDuration(); if(d > 0) dur = d; }
      if(!drag){
        const f = dur ? clamp(cur/dur,0,1) : 0;
        fill.style.width = (f*100)+'%'; knob.style.left = (f*100)+'%';
        cEl.textContent = root.classList.contains('rem') && dur ? '-'+fmt(dur-cur) : fmt(cur); seek.setAttribute('aria-valuenow', Math.round(cur)); seek.setAttribute('aria-valuemax', Math.round(dur||0));
      }
      dEl.textContent = fmt(dur);
      if(ready) buf.style.width = (clamp(yt.getVideoLoadedFraction()||0,0,1)*100)+'%';
    }
    function setIcon(){
      const playing = state === 1 || state === 3;
      playIco.className = 'ph-fill ph-'+(playing?'pause':'play');
      cls('is-paused', !playing); cls('is-loading', want && state === 3 || (want && !ready));
    }
    function wake(){
      cls('idle', false); clearTimeout(idleTmr);
      idleTmr = setTimeout(() => { if(state === 1 && !menu.classList.contains('on')) cls('idle', true); }, 2600);
    }

    /* ----- tick: ui, resume position, study time ----- */
    function tick(){
      if(dead) return;
      /* never keep playing behind a hidden view or an open exam */
      if(!root.getClientRects().length && !fsEl()){ if(state === 1) api.pause(); return; }
      const now = performance.now();
      if(state === 1){ acc += Math.min(1, (now - lastTick)/1000); }
      lastTick = now; paint();
    }
    function persist(final){
      if(!ready) return;
      const cur = yt.getCurrentTime()||0, d = dur || yt.getDuration() || 0;
      if(cur < 1 && !final) return;
      const done = vget(v.id).done || (d > 0 && cur/d > .92);
      vset(v.id, { t: done && cur/d > .97 ? 0 : cur, d, done });
      if(o.onProgress) o.onProgress(v);
    }
    function bank(){
      if(acc >= 30){ try{ endSession(Math.round(acc)); }catch(e){} }
      acc = 0;
    }

    /* ----- yt events ----- */
    function onState(e){
      const s = e.data; state = s;
      if(s === 1){ cls('is-started', 1); cls('is-shown', 1); cls('is-ended', 0); want = true; lastTick = performance.now(); wake();
      }
      if(s === 2){ persist(); bank(); cls('idle', false); }
      if(s === 0){ cls('is-ended', 1); cls('idle', false); persist(true); vset(v.id, { done:true, t:0 }); bank(); if(o.onEnd) o.onEnd(v); }
      if(s === 3) cls('is-started', 1), cls('is-shown', 1);
      setIcon(); paint();
    }
    function create(){
      want = true; cls('is-loading', 1); cls('is-err', 0);
      loadAPI().then(() => {
        if(dead) return;
        if(yt){ try{ yt.destroy(); }catch(e){} yt = null; ready = false; root.querySelector('.vp-yt').innerHTML = '<div id="'+pid+'"></div>'; }
        yt = new YT.Player(pid, {
          host:'https://www.youtube-nocookie.com', videoId:v.id, width:'100%', height:'100%',
          playerVars:{ controls:0, disablekb:1, fs:0, rel:0, modestbranding:1, playsinline:1, iv_load_policy:3, cc_load_policy:0, autoplay:1, start:Math.floor(startAt), origin:location.origin },
          events:{
            onReady(){
              if(dead) return; ready = true; dur = yt.getDuration()||dur;
              yt.setVolume(vlevel); vol.value = vlevel; vol.style.setProperty('--v', vlevel+'%'); volIco();
              yt.playVideo(); paint();
              /* phones may refuse autoplay: fall back to a calm paused state, ready for one tap */
              setTimeout(() => { if(!dead && state !== 1 && state !== 3 && state !== 0){ cls('is-started',1); cls('is-shown',1); want = false; setIcon(); } }, 2800);
            },
            onStateChange:onState,
            onError(){ if(dead) return; cls('is-err', 1); cls('is-loading', 0); want = false; }
          }
        });
        clearInterval(tmr); tmr = setInterval(tick, 250);
        clearInterval(saveTmr); saveTmr = setInterval(() => { if(state === 1) persist(); }, 5000);
      }).catch(() => { if(dead) return; cls('is-err', 1); cls('is-loading', 0); want = false; });
    }

    /* ----- controls api ----- */
    const api = {
      root, video:v,
      play(){ if(!ready){ create(); return; } if(state === 0) yt.seekTo(0, true); yt.playVideo(); },
      pause(){ if(ready) yt.pauseVideo(); },
      toggle(){ const was = state === 1 || state === 3; was ? api.pause() : api.play(); if(ready) bz(I(was ? 'pause' : 'play', 1)); },
      seekBy(d){ if(!ready) return; const t = clamp((yt.getCurrentTime()||0)+d, 0, (dur||1e9)-.2); yt.seekTo(t, true); if(state === 0) yt.playVideo(); paint(); flash(d>0?'fwd':'back'); },
      seekTo(t){ if(!ready) return; yt.seekTo(clamp(t,0,dur||1e9), true); paint(); },
      rate(r){ if(!ready) return; yt.setPlaybackRate(r); bz('<b>'+(r===1?'1':r)+'×</b>'); q('.rate b').textContent = (r===1?'1':r)+'×'; qa('.vp-menu button').forEach(b => b.classList.toggle('on', +b.dataset.r === r)); },
      destroy(){
        if(dead) return; try{ persist(); bank(); }catch(e){} dead = true; live.delete(api);
        clearInterval(tmr); clearInterval(saveTmr); clearTimeout(idleTmr);
        document.removeEventListener('fullscreenchange', onFs); document.removeEventListener('webkitfullscreenchange', onFs);
        if(fake) leaveFake();
        try{ yt && yt.destroy(); }catch(e){}
        root.remove();
      }
    };
    let skAcc = 0, skDir = 0, skT = 0;
    function bz(html){ const el = q('.vp-bz'); el.classList.remove('go'); el.innerHTML = html; void el.offsetWidth; el.classList.add('go'); }
    function flash(dir){
      cEl.animate && cEl.animate([{color:'#7ef0a8'},{color:''}], { duration:600 });
      if(dir !== 'fwd' && dir !== 'back') return;
      const d = dir === 'fwd' ? 1 : -1; skAcc = (d === skDir && skT) ? skAcc + 10 : 10; skDir = d;
      clearTimeout(skT); skT = setTimeout(() => { skT = 0; skAcc = 0; skDir = 0; }, 800);
      const el = q('.vp-sk.'+(d > 0 ? 'r' : 'l')), o2 = q('.vp-sk.'+(d > 0 ? 'l' : 'r'));
      o2.classList.remove('go'); el.classList.remove('go'); el.querySelector('span').textContent = skAcc+' seconds'; void el.offsetWidth; el.classList.add('go');
    }
    function keysToggle(on){ q('.vp-keys').classList.toggle('on', on == null ? !q('.vp-keys').classList.contains('on') : on); }

    /* ----- volume ----- */
    function volIco(){ const m = ready && yt.isMuted(); const l = m ? 0 : vlevel; muteIco.className = 'ph ph-speaker-'+(l===0?'x':l<50?'low':'high'); }
    vol.addEventListener('input', () => { vlevel = +vol.value; vol.style.setProperty('--v', vlevel+'%'); if(ready){ vlevel ? yt.unMute() : yt.mute(); yt.setVolume(vlevel); } E().vol = vlevel; saveState(); volIco(); });
    function toggleMute(){ if(!ready) return; if(yt.isMuted() || vlevel===0){ if(vlevel===0){ vlevel = 60; vol.value = 60; vol.style.setProperty('--v','60%'); yt.setVolume(60); } yt.unMute(); } else yt.mute(); volIco(); }

    /* ----- fullscreen (with a fallback for phones that cannot fullscreen an element) ----- */
    const fsEl = () => document.fullscreenElement || document.webkitFullscreenElement;
    function onFs(){ const on = fsEl() === root || fake; fsIco.className = 'ph ph-corners-'+(on?'in':'out'); }
    function enterFake(){ fake = true; root.classList.add('is-fs-fake'); document.body.style.overflow = 'hidden'; onFs(); }
    function leaveFake(){ fake = false; root.classList.remove('is-fs-fake'); document.body.style.overflow = ''; onFs(); }
    function toggleFs(){
      if(fake){ leaveFake(); return; }
      if(fsEl() === root){ (document.exitFullscreen || document.webkitExitFullscreen).call(document); return; }
      const f = root.requestFullscreen || root.webkitRequestFullscreen;
      if(f){ try{ const r = f.call(root); if(r && r.catch) r.catch(enterFake); }catch(e){ enterFake(); } } else enterFake();
    }
    document.addEventListener('fullscreenchange', onFs); document.addEventListener('webkitfullscreenchange', onFs);

    /* ----- seek bar ----- */
    const frac = e => { const r = seek.getBoundingClientRect(); return clamp((e.clientX - r.left)/r.width, 0, 1); };
    function scrub(e){ const f = frac(e); fill.style.width = (f*100)+'%'; knob.style.left = (f*100)+'%'; cEl.textContent = fmt(f*dur); return f; }
    seek.addEventListener('pointerdown', e => { if(!ready) return; drag = true; seek.classList.add('drag'); seek.setPointerCapture(e.pointerId); scrub(e); });
    seek.addEventListener('pointermove', e => {
      const f = frac(e); tip.style.left = (f*100)+'%'; tip.textContent = fmt(f*dur);
      if(drag) scrub(e);
    });
    const endDrag = e => { if(!drag) return; drag = false; seek.classList.remove('drag'); api.seekTo(frac(e)*dur); if(state === 0 || state === 5) yt.playVideo(); };
    seek.addEventListener('pointerup', endDrag); seek.addEventListener('pointercancel', () => { drag = false; seek.classList.remove('drag'); });

    /* ----- clicks ----- */
    q('.vp-poster').addEventListener('click', () => api.play());
    q('.vp-poster').addEventListener('pointerenter', () => loadAPI().catch(()=>{}), { once:true });
    root.addEventListener('touchstart', () => loadAPI().catch(()=>{}), { once:true, passive:true });
    let lastTap = 0, lastX = 0;
    const hit = q('.vp-hit');
    hit.addEventListener('pointerdown', e => { hit._wasIdle = root.classList.contains('idle'); hit._type = e.pointerType; });
    hit.addEventListener('click', e => {
      if(menu.classList.contains('on')){ menu.classList.remove('on'); return; }
      if(hit._type === 'touch'){
        const now = Date.now(), r = hit.getBoundingClientRect(), x = (e.clientX - r.left)/r.width;
        if(now - lastTap < 320 && Math.abs(x - lastX) < .3 && (x < .35 || x > .65)){ api.seekBy(x < .5 ? -10 : 10); lastTap = 0; return; }
        lastTap = now; lastX = x;
        if(hit._wasIdle){ wake(); return; }
      }
      api.toggle();
    });
    hit.addEventListener('dblclick', e => { if(hit._type === 'touch') return; api.toggle(); toggleFs(); });
    root.addEventListener('click', e => {
      const b = e.target.closest('[data-a]'); if(!b) return;
      const a = b.dataset.a;
      if(a === 'play') api.toggle(); else if(a === 'back') api.seekBy(-10); else if(a === 'fwd') api.seekBy(10);
      else if(a === 'mute') toggleMute(); else if(a === 'fs') toggleFs(); else if(a === 'retry') create();
      else if(a === 'rate') menu.classList.toggle('on'); else if(a === 'keys') keysToggle();
    });
    menu.addEventListener('click', e => { const b = e.target.closest('[data-r]'); if(!b) return; api.rate(+b.dataset.r); menu.classList.remove('on'); });
    document.addEventListener('pointerdown', e => { if(menu.classList.contains('on') && !e.target.closest('.vp-menu,[data-a=rate]')) menu.classList.remove('on'); });
    root.addEventListener('pointermove', wake); root.addEventListener('pointerdown', wake);
    root.addEventListener('pointerleave', () => { if(state === 1) { clearTimeout(idleTmr); idleTmr = setTimeout(() => cls('idle', true), 700); } });
    q('.vp-pausebtn').addEventListener('click', () => api.play());
    q('.vp-time').addEventListener('click', () => { root.classList.toggle('rem'); paint(); });
    seek.addEventListener('keydown', e => { if(e.key === 'ArrowLeft'){ e.preventDefault(); e.stopPropagation(); api.seekBy(-5); } else if(e.key === 'ArrowRight'){ e.preventDefault(); e.stopPropagation(); api.seekBy(5); } });

    /* ----- end card actions ----- */
    const row = q('.vp-end .row');
    const mk = (label, icon, c, fn) => { const b = document.createElement('button'); b.className = 'btn '+c+' sm'; b.innerHTML = I(icon)+label; b.onclick = fn; row.appendChild(b); };
    mk('Watch again', 'arrow-counter-clockwise', 'ghost', () => { cls('is-ended', 0); api.play(); });
    (o.endActions||[]).forEach(a => mk(a.label, a.icon||'arrow-right', a.cls||'acc', a.fn));

    /* ----- keyboard (only when this player is focused or hovered) ----- */
    api.key = e => {
      if(!ready) { if((e.key === ' ' || e.key === 'k') && (root.contains(document.activeElement) || root.matches(':hover'))){ e.preventDefault(); api.play(); } return; }
      const k = e.key.toLowerCase();
      if(e.metaKey || e.ctrlKey || e.altKey) return;
      if(k === 'escape' && q('.vp-keys').classList.contains('on')){ keysToggle(false); return; }
      if(k === '?' || (k === '/' && e.shiftKey)){ e.preventDefault(); keysToggle(); return; }
      if(k === 'escape' && fake){ leaveFake(); return; }
      const act = {
        ' ':() => api.toggle(), k:() => api.toggle(), j:() => api.seekBy(-10), l:() => api.seekBy(10),
        arrowleft:() => api.seekBy(-5), arrowright:() => api.seekBy(5), m:toggleMute, f:toggleFs,
        arrowup:() => { vlevel = clamp(vlevel+10,0,100); vol.value = vlevel; vol.dispatchEvent(new Event('input')); },
        arrowdown:() => { vlevel = clamp(vlevel-10,0,100); vol.value = vlevel; vol.dispatchEvent(new Event('input')); },
        '>':() => api.rate(RATES[Math.min(RATES.length-1, RATES.indexOf(yt.getPlaybackRate())+1)] || 1),
        '<':() => api.rate(RATES[Math.max(0, RATES.indexOf(yt.getPlaybackRate())-1)] || 1),
        home:() => api.seekTo(0), end:() => api.seekTo(dur-1)
      }[k] || (/^[0-9]$/.test(k) ? () => api.seekTo(dur*(+k)/10) : null);
      if(!act) return;
      if(!(root.contains(document.activeElement) || root.matches(':hover') || fsEl() === root || fake)) return;
      e.preventDefault(); act(); wake();
    };
    live.add(api);
    api.rate1 = () => api.rate(1);
    wake(); paint(); dEl.textContent = v.d ? fmt(v.d) : (saved.d ? fmt(saved.d) : '0:00');
    if(saved.d){ dur = saved.d; fill.style.width = (clamp(saved.t/saved.d,0,1)*100)+'%'; }
    if(o.autoplay) create();
    return api;
  }

  document.addEventListener('keydown', e => {
    if(/^(input|textarea|select)$/i.test((e.target.tagName||'')) && e.target.type !== 'range') return;
    live.forEach(p => p.key(e));
  });
  addEventListener('pagehide', () => live.forEach(p => { try{ p.destroy(); }catch(err){} }));

  /* ============================================================
     WATCH PAGE
     ============================================================ */
  let wFilter = 'all', wSel = null, wPlayer = null;
  const wKill = () => { if(wPlayer){ wPlayer.destroy(); wPlayer = null; } };
  const topicName = k => (typeof TOPICS !== 'undefined' && TOPICS[k]) ? TOPICS[k].short : '';
  const visible = () => LIB.filter(v => wFilter === 'all' || v.sec === wFilter);

  function pct(v){ const p = vget(v.id); return p.done ? 100 : p.d ? Math.round(clamp(p.t/p.d,0,1)*100) : 0; }

  function renderSeg(){
    const n = k => k === 'all' ? LIB.length : LIB.filter(v => v.sec === k).length;
    const tabs = [['all','Everything','stack'],['m','Math','function'],['rw','Reading & Writing','book-open-text'],['tips','Strategy','compass']].filter(t => n(t[0]));
    $('#wSeg').innerHTML = tabs.map(t => '<button data-f="'+t[0]+'" class="'+(wFilter===t[0]?'on':'')+'">'+I(t[2])+t[1]+'<small>'+n(t[0])+'</small></button>').join('');
  }
  function renderList(){
    const vs = visible(), el = $('#wList');
    const done = vs.filter(v => vget(v.id).done).length;
    el.innerHTML = '<h4>Up next<em>'+done+' / '+vs.length+' watched</em></h4><div class="w-items">'+
      vs.map(v => {
        const p = pct(v), d = vget(v.id).done;
        return '<button class="w-item'+(wSel===v.id?' on':'')+'" data-id="'+v.id+'"><div class="w-th" data-p="'+v.id+'">'+I('play',1)+'<div class="w-prog"><i style="--p:'+(d?100:p)+'%"></i></div></div>'+
          '<div class="w-meta"><b>'+esc(v.t||'Loading…')+'</b><span>'+(d?'<i class="ph-fill ph-check-circle ok"></i>Watched':esc(v.by||SEC[v.sec]))+'</span></div></button>';
      }).join('')+'</div>'+(vs.length ? '' : '<div class="w-empty">No videos here yet.</div>');
    el.querySelectorAll('.w-th').forEach(t => poster2(t, t.dataset.p));
    vs.forEach(v => { if(!v.t || !v.by) ensureMeta(v).then(() => { const b = el.querySelector('.w-item[data-id="'+v.id+'"] .w-meta'); if(b){ b.querySelector('b').textContent = v.t; if(!vget(v.id).done) b.querySelector('span').textContent = v.by||''; } }); });
  }
  function poster2(el, id){ const u = 'https://i.ytimg.com/vi/'+id+'/mqdefault.jpg'; el.style.backgroundImage = 'url("'+u+'")'; }

  function renderMain(autoplay){
    const v = byId(wSel), main = $('#wMain'); wKill();
    if(!v){ main.innerHTML = '<div class="card w-empty">No videos yet. Add links in <b>assets/data/videos.js</b>.</div>'; return; }
    const vs = visible(), i = vs.findIndex(x => x.id === v.id), next = vs[i+1];
    main.innerHTML = '<div class="w-theater" id="wTheater"><div id="wHost"></div></div><div class="w-info" id="wInfo"></div>';
    const info = () => {
      const d = vget(v.id).done, tn = topicName(v.topic);
      $('#wInfo').innerHTML =
        '<div class="kick"><span class="tag acc">'+esc(SEC[v.sec]||'Video')+'</span>'+(tn?'<span class="tag">'+esc(tn)+'</span>':'')+(d?'<span class="tag good">'+I('check-circle',1)+'Watched</span>':'')+'</div>'+
        '<h2>'+esc(v.t||'')+'</h2>'+
        (v.by?'<div class="by"><span class="av">'+esc(v.by.trim().charAt(0).toUpperCase())+'</span>'+esc(v.by)+'</div>':'')+
        (v.why?'<p class="why">'+esc(v.why)+'</p>':'')+
        '<div class="acts">'+
          (v.topic?'<button class="btn acc" id="wPrac">'+I('target')+'Practice '+esc(tn||'this topic')+'</button>':'')+
          '<button class="btn line'+(d?' done':'')+'" id="wDone">'+I(d?'check-circle':'check', d)+(d?'Watched':'Mark as watched')+'</button>'+
        '</div>';
      const pr = $('#wPrac'); if(pr) pr.onclick = () => startPractice(v.topic);
      $('#wDone').onclick = () => { const nd = !vget(v.id).done; vset(v.id, { done:nd }); toast(nd ? 'Marked as watched' : 'Marked as not watched', 'ph-check-circle'); info(); renderList(); };
    };
    info();
    const ends = [];
    if(next) ends.push({ label:'Next video', icon:'arrow-right', cls:'acc', fn:() => pick(next.id, true) });
    if(v.topic) ends.push({ label:'Practice it', icon:'target', cls:'line', fn:() => startPractice(v.topic) });
    wPlayer = makePlayer($('#wHost'), v, {
      autoplay, endActions:ends,
      glow:u => { const t = $('#wTheater'); if(t) t.style.setProperty('--glow','url("'+u+'")'); },
      onMeta:() => { info(); renderList(); },
      onProgress:() => { const it = $('#wList .w-item[data-id="'+v.id+'"] .w-prog i'); if(it) it.style.setProperty('--p', pct(v)+'%'); },
      onEnd:() => { info(); renderList(); toast('Video complete. Nicely done.', 'ph-check-circle'); }
    });
  }
  function pick(id, autoplay){
    wSel = id; vset(id, {}); /* remember the last viewed */
    renderList(); renderMain(!!autoplay);
    if(autoplay) { const t = $('#wTheater'); if(t && t.getBoundingClientRect().top < 0) scrollTo({ top:0, behavior:'smooth' }); }
  }
  function renderWatch(){
    if(!LIB.length){ $('#wMain').innerHTML = '<div class="card w-empty">No videos yet.</div>'; return; }
    renderSeg();
    if(!wSel || !byId(wSel)) wSel = (lastUnfinished() || LIB[0]).id;
    if(!visible().some(v => v.id === wSel)) wSel = visible()[0] ? visible()[0].id : null;
    renderList(); renderMain(false);
  }
  $('#wSeg').addEventListener('click', e => {
    const b = e.target.closest('[data-f]'); if(!b) return;
    wFilter = b.dataset.f; renderSeg(); const vs = visible();
    if(!vs.some(v => v.id === wSel)) { wSel = vs[0] && vs[0].id; renderList(); renderMain(false); } else renderList();
  });
  $('#wList').addEventListener('click', e => { const b = e.target.closest('.w-item'); if(b) pick(b.dataset.id, true); });

  /* public: open a given video from anywhere in the app */
  window.watchVideo = function(id, autoplay){
    if(!byId(id)) return; wFilter = 'all'; wSel = id; go('watch'); if(autoplay) pick(id, true);
  };

  /* ============================================================
     LESSONS: video block under the worked example
     ============================================================ */
  let lPlayer = null;
  const lKill = () => { if(lPlayer){ lPlayer.destroy(); lPlayer = null; } };
  function lessonVideos(topic){
    const sec = typeof TOPICS !== 'undefined' && TOPICS[topic] ? TOPICS[topic].sec : null;
    const a = LIB.filter(v => v.topic === topic), b = LIB.filter(v => v.sec === sec && v.topic !== topic);
    return a.concat(b).slice(0, 4);
  }
  const _openLesson = openLesson;
  openLesson = function(id){
    lKill(); _openLesson(id);
    const l = LESSONS.find(x => x.id === id), vs = lessonVideos(l.topic), anchor = $('#lsPrac');
    if(!vs.length || !anchor) return;
    const box = document.createElement('div'); box.className = 'lw';
    box.innerHTML = '<div class="lw-h"><div class="t">'+I('monitor-play')+'Prefer to watch? See it explained</div><button type="button" id="lwAll">All videos'+I('arrow-right')+'</button></div><div id="lwHost"></div><div class="lw-tabs" id="lwTabs"></div>';
    anchor.parentElement.parentElement.insertBefore(box, anchor.parentElement);
    const show = (v, auto) => {
      lKill();
      lPlayer = makePlayer($('#lwHost'), v, { compact:true, autoplay:auto, onEnd:() => renderTabs() });
      renderTabs(v.id);
    };
    const renderTabs = cur => {
      cur = cur || (lPlayer && lPlayer.video.id);
      $('#lwTabs').innerHTML = vs.length > 1 ? vs.map(v => '<button data-id="'+v.id+'" class="'+(v.id===cur?'on':'')+'">'+esc(v.t||'Video')+'</button>').join('') : '';
      vs.forEach(v => { if(!v.t) ensureMeta(v).then(renderTabs); });
    };
    $('#lwTabs').addEventListener('click', e => { const b = e.target.closest('[data-id]'); if(b) show(byId(b.dataset.id), true); });
    $('#lwAll').onclick = () => watchVideo(lPlayer ? lPlayer.video.id : vs[0].id);
    show(vs[0], false);
  };
  const _closeLesson = closeLesson;
  closeLesson = function(s){ lKill(); _closeLesson(s); };

  /* ============================================================
     NAV + DASHBOARD
     ============================================================ */
  const _go = go;
  go = function(n){
    if(n !== 'watch') wKill();
    if(n !== 'lessons') lKill();
    _go(n);
    if(n === 'watch') renderWatch();
  };

  const _ad = animateDash;
  animateDash = function(){
    _ad();
    const h = $('#v3home'); if(!h || !LIB.length) return;
    const cont = lastUnfinished(), n = watchedN();
    const title = cont ? 'Continue watching' : 'Watch and learn';
    const sub = cont ? esc(cont.t || 'Pick up where you left off') : (n+' of '+LIB.length+' videos watched');
    h.insertAdjacentHTML('beforeend', '<div class="card lift click" id="v3watch"><span class="ic vid">'+I('monitor-play')+'</span><div><b>'+title+'</b><div class="muted" style="font-size:13px;margin-top:4px">'+sub+'</div></div></div>');
    $('#v3watch').onclick = () => cont ? watchVideo(cont.id) : go('watch');
  };
  if(typeof currentView !== 'undefined' && currentView === 'dash') try{ animateDash(); }catch(e){}
})();
