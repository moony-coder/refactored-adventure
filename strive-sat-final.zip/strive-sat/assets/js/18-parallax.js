/* PARALLAX driver. One rAF loop writes three CSS variables; all motion lives in parallax.css. */
(function(){
  'use strict';
  if(matchMedia('(prefers-reduced-motion:reduce)').matches) return;
  var r = document.documentElement, orbs = document.createElement('div');
  orbs.className = 'px-orbs'; orbs.setAttribute('aria-hidden','true'); orbs.innerHTML = '<i></i><i></i><i></i>';
  document.body.prepend(orbs);
  var sy = 0, tx = 0, ty = 0, mx = 0, my = 0, tick = false, fine = matchMedia('(hover:hover) and (pointer:fine)').matches;
  function frame(){
    tick = false; mx += (tx - mx) * .08; my += (ty - my) * .08;
    r.style.setProperty('--sy', Math.min(sy, 1600).toFixed(1));
    r.style.setProperty('--mx', mx.toFixed(3)); r.style.setProperty('--my', my.toFixed(3));
    if(Math.abs(tx - mx) > .002 || Math.abs(ty - my) > .002) req();
  }
  function req(){ if(!tick){ tick = true; requestAnimationFrame(frame); } }
  addEventListener('scroll', function(){ sy = scrollY; req(); }, { passive:true });
  if(fine) addEventListener('pointermove', function(e){ tx = e.clientX / innerWidth * 2 - 1; ty = e.clientY / innerHeight * 2 - 1; req(); }, { passive:true });
  document.addEventListener('visibilitychange', function(){ if(document.hidden){ tx = ty = 0; } });
  req();
})();
