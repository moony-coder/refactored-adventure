/* ============================================================
   MASCOT SYSTEM: one eagle, many moods. Every event picks a mood.
   ============================================================ */
const MOOD = { wink:'m_wink', welcome:'m_welcome', thumbs:'m_thumbs', cheer:'m_cheer', trophy:'m_trophy', think:'m_think', confused:'m_confused', headache:'m_headache', cry:'m_cry', study:'m_study', listen:'m_listen' };
const moodKey = m => MOOD[m] || m;
const moodOf = k => Object.keys(MOOD).find(m => MOOD[m]===k) || '';
// Optional Gemini / Omni loops: drop a URL here (e.g. MASCOT_VIDEO.wink = 'wink.webm') and the welcome card plays it instead of the still.
const MASCOT_VIDEO = {};
function mascotHTML(mood, cls=''){
  const v = MASCOT_VIDEO[mood];
  return v ? '<video class="'+cls+'" data-mood="'+mood+'" src="'+v+'" autoplay muted loop playsinline></video>'
           : '<img class="'+cls+'" data-mood="'+mood+'" src="'+IMG[moodKey(mood)]+'" alt="">';
}
const isRW = q => (q && q._topic || '').indexOf('rw')===0;
/* score band → mascot + script line for the "done" screens */
function moodForScore(pct){
  if(pct>=85) return { art:'m_trophy', script:'Absolute<br>legend!' };
  if(pct>=70) return { art:'m_cheer',  script:'Progress looks<br>good on you!' };
  if(pct>=50) return { art:'m_thumbs', script:'Solid work,<br>bro!' };
  return { art:'m_cry', script:'Tough one.<br>We review it!' };
}
/* answer feedback in practice mode */
function coachForAnswer(q, ok){
  X.run = ok ? (X.run||0)+1 : 0;
  if(ok){
    if(X.run>=3) coachSay('m_cheer', 'On fire! '+X.run+' in a row');
    else coachSay('m_thumbs', ['Nice one, bro!','Clean work!','You got this!'][Math.floor(Math.random()*3)]);
  } else if(isRW(q)) coachSay('m_headache', 'Ouch. Read why.');
  else coachSay('m_confused', 'Hmm. Check the steps.');
}
function closeMascotCards(){ ['#mw','#mn'].forEach(s=>{ const e=$(s); if(e){ e.classList.remove('in'); e.classList.add('out'); setTimeout(()=>e.remove(),600); } }); }
/* the welcome that appears when the intro ends */
function showWelcome(){
  if($('#mw')) return;
  const isNew = state.answered===0, w = weakest(), left = daysLeft(), pr0 = estPredicted(), gap = pr0==null ? null : Math.max(0, state.profile.goal - pr0), name = esc(state.profile.name||'there');
  const bg = document.createElement('div'); bg.id='mw'; bg.setAttribute('role','dialog'); bg.setAttribute('aria-modal','true'); bg.setAttribute('aria-label','Welcome');
  bg.innerHTML =
    '<div class="mwcard"><button class="mwx" aria-label="Close"><i class="ph ph-x"></i></button>'+
    '<div class="mwmas"><span class="mwhey">Hey '+name+'!</span>'+mascotHTML('wink')+'</div>'+
    '<div class="mwtxt"><div class="eb">'+(isNew?'Welcome':'Welcome back')+'</div><h2>Ready to climb to <em>'+state.profile.goal+'</em>?</h2>'+
    '<p>'+(isNew ? 'First stop: a short diagnostic across every topic. It finds your weak spots so your plan is built around you.' : w ? 'Your weakest area right now is <b>'+esc(TOPICS[w.key].short)+'</b>. A short set today will move the needle fastest.' : 'Pick up where you left off. A short set today keeps the momentum going.')+'</p>'+
    '<div class="mwchips"><span><i class="ph-fill ph-fire"></i>'+state.streak+'-day streak</span><span><i class="ph ph-calendar-check"></i>'+left+' days to test</span><span><i class="ph ph-target"></i>'+(gap==null?'Goal '+state.profile.goal:gap+' pts to goal')+'</span></div>'+
    '<div class="mwbtns"><button class="btn acc lg" id="mwGo">'+(isNew?'Take the diagnostic':w?'Drill '+esc(TOPICS[w.key].short):'Start practice')+'<i class="ph ph-arrow-right"></i></button><button class="btn ghost lg" id="mwLater">Maybe later</button></div></div></div>';
  document.body.appendChild(bg);
  const close = () => { document.removeEventListener('keydown', onKey, true); closeMascotCards(); armIdle(); };
  const onKey = e => { if(e.key==='Escape'){ e.stopPropagation(); close(); } };
  document.addEventListener('keydown', onKey, true);
  bg.querySelector('.mwx').onclick = close; $('#mwLater').onclick = close;
  $('#mwGo').onclick = () => { close(); if(isNew) startDiagnostic(); else drillWeak(); };
  bg.addEventListener('pointerdown', e=>{ if(e.target===bg) close(); });
  requestAnimationFrame(()=>requestAnimationFrame(()=>bg.classList.add('in')));
  $('#mwGo').focus({preventScroll:true});
}
/* small corner nudge with a mood and an X */
function mascotNudge({mood, title, text, cta, fn}){
  const old = $('#mn'); if(old) old.remove();
  const d = document.createElement('div'); d.id='mn'; d.setAttribute('role','status');
  d.innerHTML = '<button class="mnx" aria-label="Dismiss"><i class="ph ph-x"></i></button>'+mascotHTML(mood)+'<div><b>'+title+'</b><p>'+text+'</p>'+(cta?'<div class="mnb"><button class="btn acc sm" id="mnGo">'+cta+'</button></div>':'')+'</div>';
  document.body.appendChild(d);
  const kill = () => { d.classList.remove('in'); setTimeout(()=>d.remove(),600); };
  d.querySelector('.mnx').onclick = kill; if(cta) $('#mnGo').onclick = () => { kill(); fn&&fn(); };
  requestAnimationFrame(()=>requestAnimationFrame(()=>d.classList.add('in')));
  setTimeout(kill, 14000);
}
/* idle: if nobody touches the dashboard for 2 minutes, the eagle checks in */
let idleT = 0, idleShown = 0;
function armIdle(){
  clearTimeout(idleT);
  idleT = setTimeout(()=>{
    const ex = $('#exam');
    if(document.hidden || $('#mw') || (ex && !ex.classList.contains('hidden')) || Date.now()-idleShown < 600000) return armIdle();
    idleShown = Date.now();
    mascotNudge({ mood:'think', title:'Still with me?', text:'A 10-minute set keeps your '+state.streak+'-day streak alive.', cta:'Quick practice', fn:()=>startPractice('mixed') });
  }, 120000);
}
['pointerdown','keydown','scroll'].forEach(ev=>addEventListener(ev, ()=>{ if(document.body.classList.contains('done')) armIdle(); }, {passive:true}));

