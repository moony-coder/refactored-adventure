/* ============================================================
   CINEMATIC INTRO · "ASCENT"  — deterministic timeline (t in ms)
   01 Ground  → 02 Altitude (score climbs) → 03 Reps (question tunnel)
   → 04 Strive (title) → iris wipe into the dashboard
   ============================================================ */
const SX_END = 12200, SX_IRIS = 10900;
let dashStarted = false, welcomed = false;
function startDash(){ if(dashStarted) return; dashStarted = true; animateDash(); }
function finish(){
  document.body.classList.remove('lock');
  document.body.classList.add('done');
  const i = $('#intro'), r = $('#sxRing');
  if(r) r.remove();
  if(i) i.remove();                 // iris is already fully open, so nothing flashes
  startDash();
  if(!welcomed){ welcomed = true; setTimeout(showWelcome, 650); }
}
(function(){
  const intro = $('#intro'); if(!intro) return;
  if(matchMedia('(prefers-reduced-motion:reduce)').matches || location.hash==='#skip') return;
  const cv = $('#sxc'), cx = cv.getContext('2d');
  const stage = $('#sxStage'), ring = $('#sxRing');
  const clamp = (x,a=0,b=1)=>Math.min(b,Math.max(a,x));
  const seg = (t,a,b)=>clamp((t-a)/(b-a));
  const lerp = (a,b,x)=>a+(b-a)*x;
  const E = {
    outExpo:x=>x>=1?1:1-Math.pow(2,-10*x),
    outCubic:x=>1-Math.pow(1-x,3),
    inCubic:x=>x*x*x,
    io:x=>x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2
  };
  function rng(seed){ return ()=>{ seed|=0; seed=seed+0x6D2B79F5|0; let t=Math.imul(seed^seed>>>15,1|seed); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
  const R = rng(20200);

  /* ---------- canvas ---------- */
  let W=0,H=0,DPR=1;
  function size(){ DPR=Math.min(2,devicePixelRatio||1); W=innerWidth; H=innerHeight; cv.width=Math.round(W*DPR); cv.height=Math.round(H*DPR); cx.setTransform(DPR,0,0,DPR,0,0); }
  size(); addEventListener('resize', size);

  // particles (normalised so resize is safe)
  const PV = Array.from({length:150},()=>({x:R(),y:R(),z:.2+.8*Math.pow(R(),1.6)}));
  const PR = Array.from({length:170},()=>({a:R()*Math.PI*2,ph:R(),w:R()}));
  const PE = Array.from({length:80},()=>({x:R(),y:R(),z:R()}));
  // integral of upward speed so streaks are a pure function of t
  const cum = new Float32Array(Math.ceil(SX_END/10)+2);
  const vel = t => 1*E.io(seg(t,1500,3500));
  for(let i=1;i<cum.length;i++) cum[i]=cum[i-1]+vel(i*10)*10;
  const dist = t => { const k=clamp(t/10,0,cum.length-2), i=k|0; return lerp(cum[i],cum[i+1],k-i); };

  const HITS = [4500,5100,5800,6500,7200];
  const WORDS = [['Read.',5100,''],['Solve.',5800,'o'],['Review.',6500,'m'],['Repeat.',7200,'']];

  function drawCanvas(t){
    cx.clearRect(0,0,W,H);
    const cxm=W/2, cym=H/2;
    /* altitude streaks (rising) */
    const aV = seg(t,150,900)*(1-seg(t,4500,5000));
    if(aV>0){
      const d = dist(t), v = vel(t);
      cx.lineCap='round';
      for(const p of PV){
        const y = (p.y*H + d*.95*p.z) % H;
        const len = 1.5 + 70*p.z*v;
        cx.strokeStyle = p.z>.65 ? `rgba(154,240,184,${aV*(.2+.5*p.z)})` : `rgba(200,235,216,${aV*(.12+.3*p.z)})`;
        cx.lineWidth = .6+1.4*p.z;
        cx.beginPath(); cx.moveTo(p.x*W,y); cx.lineTo(p.x*W,y-len); cx.stroke();
      }
    }
    /* altimeter ruler */
    const aRul = seg(t,1900,2500)*(1-seg(t,4400,4800));
    if(aRul>0){
      const val = scoreAt(t), ppp = Math.max(2.4,H/260), x0 = W - Math.min(92,W*.18);
      cx.textAlign='right'; cx.font='500 10px "JetBrains Mono",monospace';
      const span = H/2/ppp + 10, lo = Math.floor((val-span)/10)*10, hi = val+span;
      for(let p=lo;p<=hi;p+=10){
        const y = cym - (p-val)*ppp, fade = 1-Math.abs(y-cym)/(H/2);
        if(fade<=0) continue;
        const major = p%100===0, mid = p%50===0;
        const l = major?30:mid?20:10;
        cx.strokeStyle = `rgba(146,184,165,${aRul*fade*(major?.9:.45)})`; cx.lineWidth = major?1.4:1;
        cx.beginPath(); cx.moveTo(x0+34-l,y); cx.lineTo(x0+34,y); cx.stroke();
        if(mid){ cx.fillStyle=`rgba(${major?'241,250,245':'146,184,165'},${aRul*fade})`; cx.fillText(String(p),x0+34-l-8,y+3.5); }
      }
      cx.fillStyle=`rgba(74,222,128,${aRul})`; cx.shadowColor='#4ade80'; cx.shadowBlur=14;
      cx.beginPath(); cx.moveTo(x0+38,cym); cx.lineTo(x0+50,cym-6); cx.lineTo(x0+50,cym+6); cx.closePath(); cx.fill(); cx.shadowBlur=0;
      cx.strokeStyle=`rgba(74,222,128,${aRul*.35})`; cx.lineWidth=1;
      cx.beginPath(); cx.moveTo(0,cym); cx.lineTo(x0+34,cym); cx.setLineDash([2,7]); cx.stroke(); cx.setLineDash([]);
    }
    /* radial warp (tunnel) */
    const aR = seg(t,4800,5200)*(1-seg(t,7900,8100));
    if(aR>0){
      const maxR = Math.hypot(W,H)/2, ph = (t-4800)/1150;
      cx.lineCap='round';
      for(const p of PR){
        const u = (ph*(.7+.6*p.w) + p.ph) % 1, rr = u*u*maxR;
        const len = 6 + 190*u*u*u, r0 = Math.max(0,rr-len), c=Math.cos(p.a), s=Math.sin(p.a);
        cx.strokeStyle = p.w>.5 ? `rgba(126,240,168,${aR*(.15+.85*u)})` : `rgba(220,245,232,${aR*(.1+.6*u)})`;
        cx.lineWidth = .8 + 2.4*u;
        cx.beginPath(); cx.moveTo(cxm+c*r0,cym+s*r0); cx.lineTo(cxm+c*rr,cym+s*rr); cx.stroke();
      }
    }
    /* shockwaves on each beat */
    for(const h of HITS){
      const u = (t-h)/750; if(u<0||u>1) continue;
      const e = E.outExpo(u), r = e*Math.hypot(W,H)*.55;
      cx.strokeStyle = `rgba(126,240,168,${.55*(1-u)})`; cx.lineWidth = 2+10*(1-u);
      cx.beginPath(); cx.arc(cxm,cym,r,0,Math.PI*2); cx.stroke();
    }
    /* light rays + embers (title) */
    const aF = seg(t,8100,9000)*(1-seg(t,10800,11300));
    if(aF>0){
      cx.save(); cx.globalCompositeOperation='lighter';
      const ox=cxm, oy=H*1.08, L=H*1.35, base=Math.sin(t/1700)*.05;
      for(let i=0;i<11;i++){
        const a = -Math.PI/2 + (i-5)*.17 + base + Math.sin(t/900+i*1.7)*.012, w = .035 + .03*((i*7)%3);
        const g = cx.createLinearGradient(ox,oy,ox+Math.cos(a)*L,oy+Math.sin(a)*L);
        g.addColorStop(0,`rgba(126,240,168,${.34*aF})`); g.addColorStop(1,'rgba(74,222,128,0)');
        cx.fillStyle=g; cx.beginPath(); cx.moveTo(ox,oy);
        cx.lineTo(ox+Math.cos(a-w)*L,oy+Math.sin(a-w)*L); cx.lineTo(ox+Math.cos(a+w)*L,oy+Math.sin(a+w)*L); cx.fill();
      }
      cx.restore();
    }
    const aE = seg(t,8200,9100)*(1-seg(t,10800,11300));
    if(aE>0){
      for(let i=0;i<PE.length;i++){
        const p=PE[i], sp=.018+.05*p.z;
        let y = (p.y*H - t*sp) % H; if(y<0) y+=H;
        const tw = .5+.5*Math.sin(t/380+i*2.3), r = .7+1.9*p.z;
        cx.fillStyle=`rgba(154,240,184,${aE*tw*(.25+.6*p.z)})`;
        cx.beginPath(); cx.arc(p.x*W + Math.sin(t/1100+i)*10, y, r, 0, Math.PI*2); cx.fill();
      }
    }
  }

  /* ---------- score ---------- */
  const S0 = 1130, S1 = 1450;
  function scoreAt(t){ const u = seg(t,2000,4400); return S0 + (S1-S0)*(1-Math.pow(1-u,2.4)); }

  /* ---------- DOM refs ---------- */
  const $q = id => document.getElementById(id);
  const line=$q('sxLine'), dot=$q('sxDot'), capA=$q('sxCapA'), h1=$q('sxH1'), h2=$q('sxH2');
  const num=$q('sxNum'), nEl=$q('sxN'), dl=$q('sxDl'), tun=$q('sxTunnel'), word=$q('sxWord');
  const logo=$q('sxLogo'), eb=logo.querySelector('.eb'), big=$q('sxBig'), limg=$q('sxLogoImg'), tag=$q('sxTag');
  const flash=$q('sxFlash'), skip=$q('sxSkip');

  /* ---------- question tunnel cards ---------- */
  const CARDS0 = [
    ['Math · Algebra','3x + 7 = 22','What is the value of x?',1],
    ['R&W · Craft & Structure','As used in the text, “novel” most nearly means…',null,2],
    ['Math · Advanced','f(x) = x² − 5x + 6','Which is a zero of f?',0],
    ['R&W · Info & Ideas','Which choice best states the main idea of the text?',null,3],
    ['Math · Geometry','∠ABC = 90°  ·  AB = 6, BC = 8','Length of AC?',2],
    ['Math · Algebra','|x − 4| < 7','Which value satisfies it?',1],
    ['R&W · Standard English','Which choice completes the text so it conforms to conventions?',null,0],
    ['Math · Advanced','(x + 2)(x − 3) = 0','Sum of the solutions?',3],
    ['R&W · Info & Ideas','The author mentions the 1920s primarily to…',null,1],
    ['Math · Algebra','y = 2x − 3','Slope of the line?',2],
    ['R&W · Craft & Structure','What is the function of the underlined sentence?',null,2],
    ['Math · Advanced','sin θ = 3⁄5','cos θ in quadrant I?',1],
  ];
  const CARDS = CARDS0.concat(CARDS0.slice(0,4).map(c=>c.slice()));
  const L4 = ['A','B','C','D'];
  const cards = CARDS.map((c,i)=>{
    const d = document.createElement('div'); d.className='sx-card';
    d.innerHTML = `<div class="k sx-mono">${c[0]}</div><div class="q${c[2]?'':' t'}">${c[1]}</div>${c[2]?`<div class="s">${c[2]}</div>`:''}<div class="a">${L4.map((l,j)=>`<b class="${j===c[3]?'ok':''}">${l}</b>`).join('')}</div>`;
    tun.appendChild(d);
    const ang = i*2.399963 + .4, rad = .34 + .22*((i*.618)%1);
    return { el:d, ok:d.querySelector('.ok'), ang, rad, st:4900+i*150, dur:1500, rot:((i%5)-2)*3.2 };
  });

  /* ---------- title letters ---------- */
  const LET = [...'STRIVE'].map(ch=>{
    const w = document.createElement('span'); w.className='l';
    const i = document.createElement('i'); i.textContent = ch; w.appendChild(i); big.appendChild(w); return i;
  });
  const sheenBG = 'linear-gradient(100deg,#f1faf5 0 36%,#9af0b8 45%,#ffffff 50%,#9af0b8 55%,#f1faf5 64% 100%)';
  let metrics = null;
  function measure(){
    const total = big.getBoundingClientRect().width || 1; metrics = {total, offs:[]};
    const bx = big.getBoundingClientRect().left;
    LET.forEach(i=>{ const r=i.parentNode.getBoundingClientRect(); metrics.offs.push(r.left-bx); });
  }

  /* ---------- helpers ---------- */
  const fade = (el,o,y=0,blur=0,s=1)=>{ el.style.opacity=o; el.style.transform=`translateY(${y}px) scale(${s})`; el.style.filter = blur>.2?`blur(${blur}px)`:''; };
  const pad = n => String(n).padStart(2,'0');
  let lastScene = '', lastWord = -1, lastHead = '';

  /* ---------- the frame ---------- */
  function render(t){
    drawCanvas(t);

    skip.classList.toggle('show', t>900 && t<SX_IRIS);

    /* 01 · ground */
    const lineOut = 1-seg(t,2300,2800);
    line.style.opacity = seg(t,150,500)*lineOut;
    line.style.transform = `translateY(${E.inCubic(seg(t,1700,2700))*H*.62}px) scaleX(${E.outExpo(seg(t,200,1400))})`;
    dot.style.opacity = seg(t,100,500)*(1-seg(t,1400,1800));
    dot.style.transform = `scale(${1+.35*Math.sin(t/160)*(1-seg(t,900,1400))})`;
    const ca = seg(t,800,1250)*(1-seg(t,1550,1850));
    fade(capA, ca, 10*(1-seg(t,800,1250)), 6*(1-seg(t,800,1250)));

    /* 02 · altitude */
    const hv1 = seg(t,2150,2650)*(1-seg(t,3350,3650)), hv2 = seg(t,3500,4000)*(1-seg(t,4450,4750));
    fade(h1, hv1, 18*(1-seg(t,2150,2650))-10*seg(t,3350,3650), 8*(1-seg(t,2150,2650)));
    fade(h2, hv2, 18*(1-seg(t,3500,4000))-10*seg(t,4450,4750), 8*(1-seg(t,3500,4000)));
    const val = scoreAt(t), nIn = seg(t,1900,2500), push = seg(t,4450,5000);
    nEl.textContent = Math.round(val);
    nEl.classList.toggle('hit', t>=4420);
    num.style.opacity = nIn*(1-E.inCubic(seg(t,4650,5000)));
    num.style.transform = `translateY(-46%) scale(${(.92+.08*E.outExpo(nIn))*(1+E.inCubic(push)*22)})`;
    num.style.filter = push>0 ? `blur(${push*10}px)` : '';
    dl.textContent = `▲ +${Math.round(val-S0)} pts`;
    dl.style.opacity = seg(t,2600,3000);

    /* 03 · reps */
    tun.style.opacity = seg(t,4850,5000)*(1-seg(t,7850,8000));
    if(tun.style.opacity>0){
      const vmin = Math.min(W,H), cs = Math.min(W,H) < 640 ? .82 : 1;
      for(const c of cards){
        const p = (t-c.st)/c.dur;
        if(p<=0||p>=1){ c.el.style.opacity=0; continue; }
        const sc2 = (.1 + 2.1*Math.pow(p,1.8))*cs;
        const x = Math.cos(c.ang)*c.rad*vmin*(sc2/cs)*2.0, y = Math.sin(c.ang)*c.rad*vmin*(sc2/cs)*1.45;
        c.el.style.opacity = Math.min(1,p/.12)*(1-seg(p,.82,1));
        c.el.style.transform = `translate(-50%,-50%) translate(${x}px,${y}px) rotate(${c.rot*(1-p*.6)}deg) scale(${sc2})`;
        c.ok.classList.toggle('on', p>.48);
      }
    }
    let wi = -1;
    for(let i=0;i<WORDS.length;i++) if(t>=WORDS[i][1] && t<WORDS[i][1]+700+(i===3?150:0)) wi=i;
    if(wi!==lastWord){
      lastWord=wi;
      if(wi>=0){ word.textContent=WORDS[wi][0]; word.className=WORDS[wi][2]; }
    }
    if(wi>=0){
      const u = (t-WORDS[wi][1])/700, e = E.outExpo(seg(u,0,.3));
      const outv = 1-seg(u,.9,1)*.9;
      word.style.opacity = seg(u,0,.1)*outv;
      word.style.transform = `translateY(-50%) scale(${1+.55*(1-e)})`;
      word.style.filter = `blur(${16*(1-e)}px)`;
    } else { word.style.opacity=0; }

    /* camera shake on every beat */
    let sx=0, sy=0;
    for(const h of HITS){ const u=(t-h)/320; if(u>0&&u<1){ const a=(1-u)*(1-u)*9; sx+=Math.sin(u*55)*a; sy+=Math.cos(u*47)*a*.7; } }
    stage.style.transform = (sx||sy) ? `translate(${sx.toFixed(2)}px,${sy.toFixed(2)}px)` : '';

    /* white-out cut */
    let f = 0;
    if(t>=7860&&t<8000) f = seg(t,7860,8000);
    else if(t>=8000) f = 1-E.outCubic(seg(t,8000,8700));
    flash.style.opacity = f*.96;

    /* 04 · strive */
    if(!metrics && t>=8000){ logo.style.opacity=1; measure(); }
    logo.style.opacity = t>=8000 ? 1 : 0;
    fade(eb, seg(t,8350,8800)*(1-seg(t,10750,11050)), 10*(1-seg(t,8350,8800)));
    const ls = lerp(.26,-.012,E.outExpo(seg(t,8350,10200)));
    big.style.letterSpacing = ls+'em';
    const sweep = seg(t,9100,10400);
    LET.forEach((el,i)=>{
      const u = E.outExpo(seg(t,8450+i*85,9350+i*85));
      el.style.transform = `translateY(${(1-u)*108}%)`;
      if(metrics && sweep>0 && sweep<1){
        const Wd = metrics.total, shift = lerp(-1.75*Wd,-.25*Wd,E.io(sweep));
        el.style.backgroundImage = sheenBG; el.style.backgroundSize = (Wd*3)+'px 100%';
        el.style.backgroundPosition = (shift - metrics.offs[i])+'px 0';
        el.style.color = 'transparent';
      } else { el.style.backgroundImage='none'; el.style.color = '#f1faf5'; }
    });
    const li = seg(t,9500,10150);
    limg.style.opacity = E.outCubic(li);
    limg.style.clipPath = `inset(0 ${(1-E.outExpo(li))*100}% 0 0)`;
    limg.style.transform = `translateY(${(1-E.outCubic(li))*12}px)`;
    fade(tag, seg(t,10000,10450)*(1-seg(t,10750,11050)), 8*(1-seg(t,10000,10450)));
    const hold = seg(t,9000,10900);
    logo.style.transform = `scale(${1+.045*hold + E.inCubic(seg(t,10850,11450))*.35})`;
    logo.style.opacity = t>=8000 ? 1-E.outCubic(seg(t,10850,11250)) : 0;

    /* iris into the dashboard */
    if(t>=SX_IRIS){
      if(!intro._iris){ intro._iris=true; const ap=$('#app'); if(ap){ ap.style.transition='none'; setTimeout(()=>ap.style.transition='',150); } document.body.classList.add('done'); document.body.classList.remove('lock'); startDash(); }
      const q = seg(t,SX_IRIS,SX_END), u = .5*E.io(q)+.5*E.outCubic(q), r = u*Math.hypot(W,H)/2*1.04;
      const m = `radial-gradient(circle at 50% 50%, transparent ${r}px, #000 ${r+2}px)`;
      intro.style.webkitMaskImage = intro.style.maskImage = m;
      ring.style.width = ring.style.height = (r*2)+'px';
      ring.style.opacity = r>4 ? (1-seg(t,SX_END-500,SX_END)) : 0;
    }
  }

  /* ---------- clock ---------- */
  const hashT = /^#t=(\d+)/.exec(location.hash);
  let t = 0, last = 0, raf = 0, stopped = false;
  function stop(){ stopped = true; cancelAnimationFrame(raf); finish(); }
  function tick(now){
    if(stopped) return;
    const dt = last ? Math.min(100, now-last) : 16; last = now; t += dt;
    render(t);
    if(t>=SX_END){ stop(); return; }
    raf = requestAnimationFrame(tick);
  }
  window.__sxSeek = ms => { t = ms; render(ms); };
  function jumpToIris(){ if(t < SX_IRIS - 450) t = SX_IRIS - 450; }
  skip.addEventListener('click', jumpToIris);
  intro._skip = jumpToIris;

  const ready = Promise.race([
    (document.fonts && document.fonts.load ? Promise.all([document.fonts.load('800 100px "Inter Tight"'),document.fonts.load('400 20px "Source Serif 4"'),document.fonts.load('500 12px "JetBrains Mono"')]) : Promise.resolve()).catch(()=>{}),
    sleep(1400)
  ]);
  ready.then(()=>{
    if(hashT){ intro.style.transition='none'; t = +hashT[1]; render(t); return; }
    render(0); raf = requestAnimationFrame(tick);
  });
})();

