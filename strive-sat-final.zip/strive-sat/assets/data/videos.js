/* ============================================================
   VIDEO LIBRARY  -  ONE FILE, ONE LIST.
   Source: YouTube channel @marifat_jamal (Jamal Edu). Nothing is uploaded; these are links only.

   Add a video : add its id (or full link) to the list below. That's it.
   Remove one  : delete its line.
   Titles, channel and section (Math / Reading & Writing / Strategy) are filled in AUTOMATICALLY
   by the Watch tab. Videos that can't be embedded (private, removed, embedding off) are HIDDEN
   automatically, so students never see a broken player.

   Optional: start at 1:30 by writing  'ID&t=90'.
   To pin a section yourself use  v('ID','m')  ('m' Math, 'rw' Reading & Writing, 'tips' Strategy).
   Open /check-videos to see a green/red report and copy a fully-filled version of this file.
   ============================================================ */
(function(){
  const L = [];
  const v = (link, sec, topic, t, by, why) => L.push({ link, sec: sec || 'auto', topic: topic || '', t: t || '', by: by || '', why: why || '' });

  const IDS = [
    'xpCnbwAwBl4',
    'hdinjjgAv_s',
    '04Ve8nBKxiA',
    'ILYR0MBPHkM',
    '1j99x9k2F2A',
    'AGvINkfLq_0',
    '0ask9HrOJMo',
    'O4yOC6vJ6jA',
    '2pXT3FGONjA',
    'tWWi-DHJccY',
    '9Ahmxsicbog',
    '_WD7DGvDl3s',
    'WVt0RGSGTc8',
    'pzOHI2smaFE',
    'jZvBtGrZaPg',
    'MFM0DZ4BxY8',
    'wUCTno15xVs',
    '405PygMzNSo',
    'vRTSmKpejpE',
    'QvADti564ek',
    'rnWKY4Yr-CU',
    'ECzecPOGfeI',
    'YPq7lyeA2sU',
    'nc77wlYikas',
    '2hZXzAkOCqk',
    'Zjvlajqora8',
    'FQpG4XvScqU',
    '6ubtoKaKKXQ',
    'Xag36x4w8AU',
    'yPqjDrDmabg',
    'mgDU_tF3BsM',
    'Siwf9ab4IWQ',
    'Plxz3gXuaSQ',
    '-ZpAQGgBM3Q',
    'nQjVRgHg3X0',
  ];
  IDS.forEach(id => v(id));

  window.VIDEOS = L;
  window.VIDEO_CHANNEL = 'Jamal Edu';   // used by the checker to flag videos from other channels
})();
