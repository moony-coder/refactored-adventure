# Mascot kit: generate the whole set in 3 Gemini runs, drop it in with 1 click

Character (from your current art): white eagle, green eyes, black gaming headset with green accents, forest-green hoodie with a white wing emblem.

## Workflow (about 10 minutes)
1. Open Gemini, upload your current `m_welcome.webp` (as PNG/screenshot) as the **style/character reference**. Paste PROMPT A. Save the image as **sheet-a.png**.
2. New message in the SAME chat: upload sheet-a.png and paste PROMPT B. Save as **sheet-b.png**. (Using sheet A as reference is what keeps the character consistent.)
3. Same chat, paste PROMPT C. Save as **hero.png**.
4. Open `/mascot-slicer` on your site (or double-click `mascot-slicer.html`), drop the 3 images in, press **Download ZIP**.
5. Unzip into `assets/img/` and overwrite. Done. No code changes.

If a sheet comes out with a pose in the wrong cell, the slicer lets you swap names from a dropdown. Never regenerate one pose at a time.

## Shared style block (already included in A, B and C)
Premium 3D-rendered mascot look (Pixar-quality stylised, clean cel-shading, crisp even line weight). One lighting setup: soft key light from top-left, mint-green rim light from the right. Palette: forest #02150f and #06281d, mint #4ade80, white feathers, gold beak #f5c451. No text, no logos other than the hoodie wing emblem, no shadows on the ground, no props except where named.

## PROMPT A (6 poses)
```
Using the attached image as the exact character reference (same eagle, same face, same headset, same green hoodie with white wing emblem, same proportions), create ONE character sheet image: a 3 columns x 2 rows grid, 6 poses, each pose full body or 3/4 body, same scale, centred in its cell with wide empty spacing so nothing touches a neighbouring cell or the image edge.
Reading order, left to right, top to bottom:
1 waving with one hand, big friendly smile
2 hand on chin, thinking, one eyebrow raised
3 writing on a tablet with a stylus, focused
4 thumbs up, confident grin
5 both fists raised, laughing with joy
6 holding a golden trophy overhead, proud
Premium 3D-rendered mascot look, clean cel-shading, even line weight. Soft key light top-left, mint-green rim light from the right. Palette: forest green #02150f/#06281d, mint #4ade80, white feathers, gold beak #f5c451.
BACKGROUND: perfectly flat solid pure magenta #FF00FF everywhere, no gradient, no floor, no shadows, no grid lines, no text, no labels. Square image, highest resolution.
```

## PROMPT B (5 poses, uses sheet A as reference)
```
Using the attached sheet as the exact character reference (identical character, face, headset, hoodie, line weight, lighting and palette as all 6 poses on it), create ONE new sheet: a 3 columns x 2 rows grid with 5 poses (leave the 6th cell completely empty), same scale and spacing rules.
Reading order:
1 winking with one eye and pointing at the viewer
2 wearing the headset with one hand pressed to an ear, listening
3 shrugging with both palms open, confused
4 hand pressed on forehead, stressed headache look
5 wiping a tear from one eye, sad but cute
Same lighting: soft key top-left, mint rim light from the right.
BACKGROUND: perfectly flat solid pure magenta #FF00FF everywhere, no shadows, no text. Square image, highest resolution.
```

## PROMPT C (hero scene, 16:9)
```
Using the attached sheet as the exact character reference, create a wide 16:9 cinematic scene. The eagle mascot stands on the RIGHT third, giving a confident thumbs up, waist-up, large in frame. The LEFT two thirds is a dark study room in deep forest green (#02150f) with soft out-of-focus mint desk lamps and a faint glowing monitor, lots of empty dark space for text overlay. Same lighting language: mint-green rim light on the mascot. Premium, moody, high-end game-launcher look. No text, no logos, no UI.
```

## Sizes and filenames (the slicer produces exactly this)
| File | Size | Source |
|---|---|---|
| m_welcome, m_think, m_study, m_thumbs, m_cheer, m_trophy | 1024x1024 WebP, transparent | sheet A cells 1-6 |
| m_wink, m_listen, m_confused, m_headache, m_cry | 1024x1024 WebP, transparent | sheet B cells 1-5 |
| avatar | 256x256 WebP, transparent | auto-cropped from m_welcome (head) |
| hero | 1600x900 WebP | PROMPT C |

Each pose is trimmed, centred, with 6% padding and feet at the bottom, as MASCOT-BRIEF.md asks. The magenta is removed with soft edges and colour spill cleaned.

## If Gemini adds a faint grid, checkerboard or text
Reply in the same chat: "Regenerate exactly the same, but with a perfectly flat solid #FF00FF background, no checkerboard, no labels."
