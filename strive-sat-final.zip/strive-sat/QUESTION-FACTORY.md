# Question factory: add hundreds of questions with one prompt

## Upfront: College Board Question Bank
I could not access it from here, and I would not copy it even if I could. Those questions are College Board's copyrighted material and its terms are for personal study, not for republishing inside your own product. Check their terms yourself, or email them for a licence. What is already done instead:
- `assets/data/questions-extra.js`: 110 new ORIGINAL questions (90 Math, 20 R&W). Math answers are computer-verified. Total is now 231.
- Below: a master prompt so Gemini writes unlimited original questions in the exact format, and `/check-questions` catches mistakes before they go live.

## Master prompt (paste into Gemini; change the two bracketed parts)
```
You are an expert SAT item writer. Write [25] ORIGINAL Digital SAT questions for: [Reading & Writing - Standard English Conventions, mixed difficulty]. Do NOT copy or closely paraphrase any real SAT, College Board, Khan or Bluebook question. Invent new passages and numbers.

Output ONLY a JSON array, no commentary, no code fences. Each item exactly:
{"id":"g-001","sec":"rw"|"m","dom":"<official domain>","skill":"<official skill>","diff":"Easy"|"Medium"|"Hard","spr":false,"q":"<question stem>","passage":"<passage, only for rw, otherwise omit>","opts":["A text","B text","C text","D text"],"a":<0-3 index of correct option>,"why":"<2-4 sentence explanation naming the rule/step and why the best distractor is wrong>"}
For Math grid-in use "spr":true,"opts":null,"ans":["<answer>"] and omit "a".

Rules: exactly 4 options, one defensible answer, plausible distractors from common mistakes, no "all of the above". Use − (U+2212) for minus. Math: solve each problem twice by two different methods and discard any item where answers differ. R&W: the passage must make exactly one option correct. Vary answer positions evenly. Official domains: Reading & Writing = Craft and Structure, Information and Ideas, Standard English Conventions, Expression of Ideas. Math = Algebra, Advanced Math, Problem-Solving and Data Analysis, Geometry and Trigonometry.
```
Tip: run it 10 times (change the skill each time) for 250+ questions.

## Loading them (copy-paste, no file editing)
1. Open `/check-questions` on your site, paste Gemini's output, press **Check**.
2. Fix or delete flagged items (it names the id and problem), then **Copy file**.
3. Replace the contents of `assets/data/questions-extra.js` with what you copied. Done.

Always skim the Math `why` lines yourself. Gemini can be confidently wrong, and the checker proves format, not truth.
