# Mascot upgrade brief

The code now presents the mascot professionally (floor shadow, glow, idle motion, speech bubbles).
The remaining gap is the artwork itself: the current poses are AI-style illustrations with uneven lighting and crops.
To reach a studio-grade result, replace the files in `assets/img/` with ONE consistent set. No code changes needed:
keep the same file names and the app picks them up.

## Spec
- Format: transparent WebP (or PNG), 1024 x 1024, mascot centred, feet/base at the bottom with ~6% padding
- One character sheet, one lighting setup (soft key from top-left, green rim light from the right), same line weight and palette
- Palette: forest #02150f / #06281d, mint #4ade80, white feathers, gold beak #f5c451
- No background, no cast shadow baked in (the app draws it), no text in the image

## Poses (file name -> where it appears)
| File | Pose | Used for |
|---|---|---|
| m_welcome | waving, big smile | onboarding, first launch |
| m_think | hand on chin | Study plan, Watch, wrong answer |
| m_study | writing on a tablet | Practice, Question bank |
| m_thumbs | thumbs up | Home hero, Analytics, correct answer |
| m_cheer | fists up, laughing | set complete (good score) |
| m_trophy | holding a trophy | Rewards, badges |
| m_wink | wink + point | tips, empty states |
| m_listen | headset, listening | Settings |
| m_confused | shrug, open hands | Lessons, empty states |
| m_headache | hand on forehead | hard question |
| m_cry | wiping a tear | low score |
| hero | wide scene, 1600 x 900 | Home hero (mascot right third, dark room left) |
| avatar | head only, 256 x 256 | sidebar profile |

Send the files back and they drop straight in.
