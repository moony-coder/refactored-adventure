# Strive SAT, Jamal's International Academy

Static site, no build step. **Run locally:** open THIS folder (the one containing `index.html`) in VS Code and press Go Live, or deploy it to Vercel. All paths are relative, so it also works from any sub-folder. Upload this folder to Vercel (Framework Preset: **Other**, no build command, output directory: root).

## Pages
| URL | File | What |
|---|---|---|
| `/` (`index.html`) | `index.html` | Sends new students to `/onboarding`, returning students to `/app` |
| `/onboarding` | `onboarding.html` | 7-step setup: name, grade, test date, goal, starting score, daily goal, summary |
| `/onboarding?edit` | same | Re-run setup later without losing progress |
| `/app` | `app.html` | The whole app (dashboard, practice, bank, tests, lessons, watch, analytics, review, plan, rewards) |

## Folder
- `assets/css` styles (`icons.css` icon font rules, `app.css`, `onboarding.css`, `fonts.css`)
- `assets/js` app code in load order (`01-core` ... `14-plus-onboarding`, `99-boot`), `config.js` = your settings
- `assets/data` question bank, lessons-era content, SAT dates
- `assets/img`, `assets/fonts` real image/font files (no more base64 inside HTML)

## What's new (read this first)
- **Videos**: one list in `assets/data/videos.js` (35 @marifat_jamal videos). Titles, sections and channel are filled in by the app; videos that can't embed hide themselves. Open `/check-videos` for a green/red report.
- **Parallax**: `assets/css/parallax.css` + `assets/js/18-parallax.js` (scroll + pointer depth, off for reduced-motion). Browser-default scrolling is untouched.
- **Mascots**: `MASCOT-GEMINI-KIT.md` (3 prompts) + `/mascot-slicer`.
- **Questions**: `assets/data/questions-extra.js` (+110), `QUESTION-FACTORY.md`, `/check-questions`.
- Accounts, sync and payments are intentionally not built yet.

## Video lessons (Watch tab)
Videos are **links only**. Nothing is uploaded or stored. Open `assets/data/videos.js` and add one line per video:

```js
v('https://www.youtube.com/watch?v=XXXXXXXXXXX', 'm', 'math_algebra', 'Title', 'Channel', 'One-line why watch');
```
- Any YouTube link works (watch, youtu.be, shorts, embed, or the bare id). Add `&t=90` to start at 1:30.
- Section: `m` (Math), `rw` (Reading & Writing), `tips` (Strategy). Topic links the video to Practice and Lessons.
- Title and channel can be left as `''`; the site fetches them.
- The player is fully custom (our poster, controls, colours). Nothing from YouTube loads until a student presses play.
- Students' progress and resume position are saved in their browser. Videos also appear under each Lesson and on the Home screen.
- Keys: Space/K play, J/L skip 10s, arrows 5s, M mute, F fullscreen, `<` `>` speed.
- **Check each link before you ship.** Some uploaders switch off embedding; those videos show a friendly "will not play here" card with an "Open original" button. Pick videos that play inside the Watch tab.

## Settings (`assets/js/config.js`)
`checkoutUrl` empty = no paywall, everything free. See "Plus" below.

## Data: what is real
Nothing is pre-filled. A student starts at 0 and every number comes from what they answered. Scores show "—" until 5+ answers in each section.
Progress is saved in the student's own browser (localStorage key `strive_sat_v3`). Clearing browser data, or switching phone/laptop, starts fresh.

## Plus / payments
The old version unlocked Plus for free. That is removed. To sell Plus for real you need accounts + a server that verifies payment (Stripe webhook). Until then keep `checkoutUrl` empty.

## Add questions
Edit `assets/data/questions.js` (`QB`) or `assets/data/content-bank.js` (`BANK`). Keep the same fields as existing items.

## Design layers (added)
- `assets/css/next.css` + `assets/js/16-next.js`: custom select / date / number / range, tooltips, scrollers, confirm, command palette (Ctrl/Cmd+K)
- `assets/css/pro.css` + `assets/js/17-motion.js`: view transitions, staggered entrances, sliding nav pill, card tilt, ripples, hero and mascot finish
- `MASCOT-BRIEF.md`: spec for a professional replacement mascot set


## Build notes (merged release)
- Base: the "updated" build (videos, parallax, extra questions, tools) with relative paths so it runs under Live Server, file or Vercel.
- Mascots: new 1024px set from `mascots.zip` in `assets/img/` (same filenames).
- Questions: 25 `g-` Standard English Conventions items merged into `questions-extra.js`; six were rewritten because they had two valid answers, and answer positions were balanced.
- Legal: items in `questions.js` whose explanations read "Choice X is the best answer because..." appear to be College Board text. Replace them before a public launch.
